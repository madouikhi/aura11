class Task {
  final String id;
  String title;
  bool isCompleted;
  String bucket; // 'today' or 'later'
  bool rolledOver;
  final DateTime createdAt;

  Task({
    required this.id,
    required this.title,
    this.isCompleted = false,
    this.bucket = 'today',
    this.rolledOver = false,
    DateTime? createdAt,
  }) : createdAt = createdAt ?? DateTime.now();

  Map<String, dynamic> toJson() => {
    'id': id,
    'title': title,
    'isCompleted': isCompleted,
    'bucket': bucket,
    'rolledOver': rolledOver,
    'createdAt': createdAt.toIso8601String(),
  };

  factory Task.fromJson(Map<String, dynamic> json) => Task(
    id: json['id'].toString(),
    title: json['title'] ?? '',
    isCompleted: json['isCompleted'] ?? false,
    bucket: json['bucket'] ?? 'today',
    rolledOver: json['rolledOver'] ?? false,
    createdAt: json['createdAt'] != null
        ? DateTime.tryParse(json['createdAt']) ?? DateTime.now()
        : DateTime.now(),
  );
}
