import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class LocationService {
  static const String _cacheKey = 'aura_cached_country';
  static String _currentCountry = 'Türkiye';

  static String get syncCountry => _currentCountry;

  static Future<String> getLocation() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final cached = prefs.getString(_cacheKey);
      if (cached != null && cached.isNotEmpty) {
        _currentCountry = cached;
      }
    } catch (_) {}

    // Silent background refresh (never blocks UI)
    _fetchFreshCountry();

    return _currentCountry;
  }

  static void _fetchFreshCountry() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final res = await http.get(Uri.parse('https://ipwho.is/')).timeout(const Duration(seconds: 4));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['success'] != false && data['country'] != null) {
          final country = data['country'].toString();
          _currentCountry = country;
          await prefs.setString(_cacheKey, country);
          return;
        }
      }
    } catch (_) {
      try {
        final res2 = await http.get(Uri.parse('https://freeipapi.com/api/json')).timeout(const Duration(seconds: 4));
        if (res2.statusCode == 200) {
          final d2 = jsonDecode(res2.body);
          if (d2['countryName'] != null) {
            final country = d2['countryName'].toString();
            _currentCountry = country;
            final prefs = await SharedPreferences.getInstance();
            await prefs.setString(_cacheKey, country);
            return;
          }
        }
      } catch (_) {}
    }
  }
}
