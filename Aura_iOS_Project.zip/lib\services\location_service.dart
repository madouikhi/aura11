import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class LocationService {
  static const String _cacheKey = 'aura_cached_location';

  static Future<String> getLocation() async {
    final prefs = await SharedPreferences.getInstance();
    final cached = prefs.getString(_cacheKey);

    // Fetch fresh in background or if no cache
    _fetchFreshLocation(prefs);

    if (cached != null && cached.isNotEmpty && cached != 'Detecting...') {
      return cached;
    }
    return 'Locating...';
  }

  static Future<void> _fetchFreshLocation(SharedPreferences prefs) async {
    try {
      final res = await http.get(Uri.parse('https://ipwho.is/')).timeout(const Duration(seconds: 4));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['success'] != false && data['city'] != null && data['country'] != null) {
          final loc = "${data['city']}, ${data['country']}";
          await prefs.setString(_cacheKey, loc);
          return;
        }
      }
    } catch (_) {
      try {
        final res2 = await http.get(Uri.parse('https://freeipapi.com/api/json')).timeout(const Duration(seconds: 4));
        if (res2.statusCode == 200) {
          final d2 = jsonDecode(res2.body);
          if (d2['cityName'] != null && d2['countryName'] != null) {
            final loc = "${d2['cityName']}, ${d2['countryName']}";
            await prefs.setString(_cacheKey, loc);
            return;
          }
        }
      } catch (_) {}
    }

    if (prefs.getString(_cacheKey) == null) {
      await prefs.setString(_cacheKey, 'Karamursel, Türkiye');
    }
  }
}
