import 'package:flutter/cupertino.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';
import '../models/task.dart';
import '../services/storage_service.dart';
import '../services/location_service.dart';
import '../services/audio_service.dart';
import 'notes_view.dart';

class TodayView extends StatefulWidget {
  final VoidCallback onOpenNoteEditor;

  const TodayView({super.key, required this.onOpenNoteEditor});

  @override
  State<TodayView> createState() => TodayViewState();
}

class TodayViewState extends State<TodayView> {
  String _country = 'TÜRKIYE';
  List<Task> _todayTasks = [];
  String _bedtime = '23:30';
  String _waketime = '07:00';
  String _sleepTotal = '7.5 hrs';
  bool _alarmEnabled = true;
  bool _isPlayingAudio = false;

  @override
  void initState() {
    super.initState();
    _loadImmediate();
    refresh();
  }

  void _loadImmediate() {
    _country = LocationService.syncCountry.toUpperCase();
  }

  Future<void> refresh() async {
    // 1. Instant local read (0ms delay)
    final tasks = await StorageService.loadTasks();
    final sleep = await StorageService.loadSleepTimes();
    final alarm = await StorageService.loadAlarmEnabled();
    final country = await LocationService.getLocation();

    final todayList = tasks.where((t) => t.bucket == 'today').toList();
    // Sort: Fresh tasks first, and Yesterday's unfinished tasks below them!
    todayList.sort((a, b) {
      if (a.rolledOver == b.rolledOver) return 0;
      return a.rolledOver ? 1 : -1;
    });

    if (mounted) {
      setState(() {
        _country = country.toUpperCase();
        _todayTasks = todayList;
        _bedtime = sleep['start'] ?? '23:30';
        _waketime = sleep['end'] ?? '07:00';
        _alarmEnabled = alarm;
        _calcSleep();
      });
    }
  }

  void _calcSleep() {
    try {
      final bParts = _bedtime.split(':').map(int.parse).toList();
      final wParts = _waketime.split(':').map(int.parse).toList();
      int bMinutes = bParts[0] * 60 + bParts[1];
      int wMinutes = wParts[0] * 60 + wParts[1];
      if (wMinutes <= bMinutes) wMinutes += 24 * 60;
      final diffHrs = (wMinutes - bMinutes) / 60.0;
      _sleepTotal = '${diffHrs.toStringAsFixed(1)} hrs';
    } catch (_) {
      _sleepTotal = '7.5 hrs';
    }
  }

  Future<void> _toggleAlarm() async {
    HapticFeedback.mediumImpact();
    setState(() {
      _alarmEnabled = !_alarmEnabled;
    });
    await StorageService.saveAlarmEnabled(_alarmEnabled);
  }

  void _pickTime(bool isBedtime) {
    HapticFeedback.selectionClick();
    final currentStr = isBedtime ? _bedtime : _waketime;
    final parts = currentStr.split(':').map(int.parse).toList();
    final initialDate = DateTime(2026, 1, 1, parts[0], parts[1]);
    DateTime selectedDate = initialDate;

    showCupertinoModalPopup(
      context: context,
      builder: (ctx) => Container(
        height: 280,
        color: const Color(0xFF16161A),
        child: Column(
          children: [
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              decoration: const BoxDecoration(
                border: Border(bottom: BorderSide(color: Color(0x1AFFFFFF), width: 0.5)),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  CupertinoButton(
                    padding: EdgeInsets.zero,
                    child: const Text('Cancel', style: TextStyle(color: Color(0xFF8E8E93), fontSize: 14)),
                    onPressed: () => Navigator.of(ctx).pop(),
                  ),
                  Text(
                    isBedtime ? 'Edit Bedtime' : 'Edit Wake Time',
                    style: const TextStyle(color: CupertinoColors.white, fontSize: 14, fontWeight: FontWeight.w600),
                  ),
                  CupertinoButton(
                    padding: EdgeInsets.zero,
                    child: const Text('Save', style: TextStyle(color: CupertinoColors.white, fontSize: 14, fontWeight: FontWeight.w700)),
                    onPressed: () async {
                      Navigator.of(ctx).pop();
                      HapticFeedback.mediumImpact();
                      final timeStr = DateFormat('HH:mm').format(selectedDate);
                      if (isBedtime) {
                        _bedtime = timeStr;
                      } else {
                        _waketime = timeStr;
                      }
                      _calcSleep();
                      setState(() {});
                      await StorageService.saveSleepTimes(_bedtime, _waketime);
                    },
                  ),
                ],
              ),
            ),
            Expanded(
              child: CupertinoDatePicker(
                mode: CupertinoDatePickerMode.time,
                initialDateTime: initialDate,
                use24hFormat: true,
                onDateTimeChanged: (dt) => selectedDate = dt,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _toggleAudioTest(bool isWake) async {
    HapticFeedback.lightImpact();
    if (_isPlayingAudio) {
      await AudioService.stop();
      setState(() => _isPlayingAudio = false);
    } else {
      setState(() => _isPlayingAudio = true);
      if (isWake) {
        await AudioService.playWake();
      } else {
        await AudioService.playSleep();
      }
      setState(() => _isPlayingAudio = false);
    }
  }

  Future<void> _toggleTask(Task task) async {
    HapticFeedback.lightImpact();
    setState(() {
      task.isCompleted = !task.isCompleted;
    });
    final allTasks = await StorageService.loadTasks();
    final idx = allTasks.indexWhere((t) => t.id == task.id);
    if (idx != -1) {
      allTasks[idx] = task;
      await StorageService.saveTasks(allTasks);
    }
  }

  @override
  Widget build(BuildContext context) {
    final now = DateTime.now();
    final dateHeading = DateFormat('EEEE, MMM d').format(now);

    return CupertinoPageScaffold(
      backgroundColor: const Color(0xFF0C0C0E),
      child: SafeArea(
        child: ListView(
          physics: const BouncingScrollPhysics(parent: AlwaysScrollableScrollPhysics()),
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
          children: [
            // Top Date & Country Header
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(
                  children: [
                    const Icon(CupertinoIcons.globe, size: 12, color: Color(0xFF8E8E93)),
                    const SizedBox(width: 5),
                    Text(
                      _country,
                      style: const TextStyle(
                        color: Color(0xFF8E8E93),
                        fontSize: 10,
                        fontWeight: FontWeight.w700,
                        letterSpacing: 0.8,
                      ),
                    ),
                  ],
                ),
                const Text(
                  'TODAY',
                  style: TextStyle(
                    color: Color(0xFF71717A),
                    fontSize: 10,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 1.0,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 4),
            Text(
              dateHeading,
              style: const TextStyle(
                color: CupertinoColors.white,
                fontSize: 26,
                fontWeight: FontWeight.w700,
                letterSpacing: -0.5,
              ),
            ),
            const SizedBox(height: 18),

            // Quick Note Card
            Container(
              decoration: BoxDecoration(
                color: const Color(0xFF131317),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: const Color(0x14FFFFFF)),
              ),
              padding: const EdgeInsets.all(14),
              child: Row(
                children: [
                  Container(
                    width: 36,
                    height: 36,
                    decoration: BoxDecoration(
                      color: const Color(0x1AFFB340),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: const Color(0x33FFB340)),
                    ),
                    child: const Icon(CupertinoIcons.square_pencil_fill, size: 18, color: Color(0xFFFFB340)),
                  ),
                  const SizedBox(width: 12),
                  const Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('Quick Note', style: TextStyle(color: CupertinoColors.white, fontSize: 13, fontWeight: FontWeight.w700)),
                        SizedBox(height: 2),
                        Text('Capture thought or idea', style: TextStyle(color: Color(0xFF71717A), fontSize: 11)),
                      ],
                    ),
                  ),
                  CupertinoButton(
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                    color: CupertinoColors.white,
                    borderRadius: BorderRadius.circular(12),
                    onPressed: widget.onOpenNoteEditor,
                    child: const Text('Write', style: TextStyle(color: CupertinoColors.black, fontSize: 12, fontWeight: FontWeight.w700)),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),

            // Sleep & Routine Card with Bell Alarm Toggle & Editable Times
            Container(
              decoration: BoxDecoration(
                color: const Color(0xFF131317),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: const Color(0x14FFFFFF)),
              ),
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  // Header with Duration & Bell Alarm Toggle
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        children: [
                          const Icon(CupertinoIcons.moon_fill, size: 14, color: Color(0xFF8E8E93)),
                          const SizedBox(width: 6),
                          const Text('SLEEP & ALARM', style: TextStyle(color: Color(0xFF8E8E93), fontSize: 11, fontWeight: FontWeight.w700, letterSpacing: 1.0)),
                          const SizedBox(width: 8),
                          Text(_sleepTotal, style: const TextStyle(color: Color(0xFF71717A), fontSize: 11, fontWeight: FontWeight.w600)),
                        ],
                      ),
                      // Bell Icon Toggle
                      GestureDetector(
                        onTap: _toggleAlarm,
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 200),
                          padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
                          decoration: BoxDecoration(
                            color: _alarmEnabled ? const Color(0x22FFB340) : const Color(0x14FFFFFF),
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(
                              color: _alarmEnabled ? const Color(0x66FFB340) : const Color(0x1AFFFFFF),
                            ),
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(
                                _alarmEnabled ? CupertinoIcons.bell_fill : CupertinoIcons.bell_slash_fill,
                                size: 12,
                                color: _alarmEnabled ? const Color(0xFFFFB340) : const Color(0xFF8E8E93),
                              ),
                              const SizedBox(width: 5),
                              Text(
                                _alarmEnabled ? 'ALARM ON' : 'ALARM OFF',
                                style: TextStyle(
                                  color: _alarmEnabled ? const Color(0xFFFFB340) : const Color(0xFF8E8E93),
                                  fontSize: 10,
                                  fontWeight: FontWeight.w700,
                                  letterSpacing: 0.5,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 14),

                  // Interactive Bedtime & Wake Up Buttons
                  Row(
                    children: [
                      // Bedtime Box
                      Expanded(
                        child: GestureDetector(
                          onTap: () => _pickTime(true),
                          child: Container(
                            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                            decoration: BoxDecoration(
                              color: const Color(0xFF1A1A20),
                              borderRadius: BorderRadius.circular(14),
                              border: Border.all(color: const Color(0x14FFFFFF)),
                            ),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    const Text('Bedtime', style: TextStyle(color: Color(0xFF71717A), fontSize: 11)),
                                    const SizedBox(height: 3),
                                    Text(_bedtime, style: const TextStyle(color: CupertinoColors.white, fontSize: 16, fontWeight: FontWeight.w700)),
                                  ],
                                ),
                                const Icon(CupertinoIcons.pencil, size: 14, color: Color(0xFF636366)),
                              ],
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 10),
                      // Wake Up Box
                      Expanded(
                        child: GestureDetector(
                          onTap: () => _pickTime(false),
                          child: Container(
                            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                            decoration: BoxDecoration(
                              color: const Color(0xFF1A1A20),
                              borderRadius: BorderRadius.circular(14),
                              border: Border.all(color: const Color(0x14FFFFFF)),
                            ),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    const Text('Wake Up', style: TextStyle(color: Color(0xFF71717A), fontSize: 11)),
                                    const SizedBox(height: 3),
                                    Text(_waketime, style: const TextStyle(color: CupertinoColors.white, fontSize: 16, fontWeight: FontWeight.w700)),
                                  ],
                                ),
                                const Icon(CupertinoIcons.pencil, size: 14, color: Color(0xFF636366)),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),

                  // Sound Preview Row
                  Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      const Text(
                        'Test Sound:',
                        style: TextStyle(color: Color(0xFF636366), fontSize: 10, fontWeight: FontWeight.w600),
                      ),
                      const SizedBox(width: 8),
                      GestureDetector(
                        onTap: () => _toggleAudioTest(true),
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                          decoration: BoxDecoration(
                            color: const Color(0x14FFFFFF),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: const Row(
                            children: [
                              Icon(CupertinoIcons.play_arrow_solid, size: 9, color: Color(0xFFA1A1AA)),
                              SizedBox(width: 3),
                              Text('Wake', style: TextStyle(color: Color(0xFFA1A1AA), fontSize: 10, fontWeight: FontWeight.w600)),
                            ],
                          ),
                        ),
                      ),
                      const SizedBox(width: 6),
                      GestureDetector(
                        onTap: () => _toggleAudioTest(false),
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                          decoration: BoxDecoration(
                            color: const Color(0x14FFFFFF),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: const Row(
                            children: [
                              Icon(CupertinoIcons.play_arrow_solid, size: 9, color: Color(0xFFA1A1AA)),
                              SizedBox(width: 3),
                              Text('Sleep', style: TextStyle(color: Color(0xFFA1A1AA), fontSize: 10, fontWeight: FontWeight.w600)),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),

            // Today Tasks Preview Section
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text('TODAY PRIORITIES', style: TextStyle(color: Color(0xFF71717A), fontSize: 11, fontWeight: FontWeight.w700, letterSpacing: 1.0)),
                Text('${_todayTasks.where((t) => t.isCompleted).length}/${_todayTasks.length} Done', style: const TextStyle(color: Color(0xFF71717A), fontSize: 11)),
              ],
            ),
            const SizedBox(height: 10),

            if (_todayTasks.isEmpty)
              Container(
                decoration: BoxDecoration(
                  color: const Color(0xFF131317),
                  borderRadius: BorderRadius.circular(18),
                  border: Border.all(color: const Color(0x14FFFFFF)),
                ),
                padding: const EdgeInsets.all(22),
                alignment: Alignment.center,
                child: const Text('No priorities set for today.\nSwitch to Tasks tab to add up to 4 priorities.',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: Color(0xFF71717A), fontSize: 12, height: 1.4),
                ),
              )
            else
              ..._todayTasks.map((task) {
                return Container(
                  margin: const EdgeInsets.only(bottom: 8),
                  decoration: BoxDecoration(
                    color: const Color(0xFF131317),
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: const Color(0x14FFFFFF)),
                  ),
                  child: CupertinoListTile(
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                    leading: GestureDetector(
                      onTap: () => _toggleTask(task),
                      child: Container(
                        width: 24,
                        height: 24,
                        decoration: BoxDecoration(
                          color: task.isCompleted ? CupertinoColors.white : CupertinoColors.transparent,
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(
                            color: task.isCompleted ? CupertinoColors.white : const Color(0xFF3F3F46),
                            width: 1.5,
                          ),
                        ),
                        child: task.isCompleted
                            ? const Icon(CupertinoIcons.checkmark, size: 14, color: CupertinoColors.black)
                            : null,
                      ),
                    ),
                    title: Text(
                      task.title,
                      style: TextStyle(
                        color: task.isCompleted ? const Color(0xFF71717A) : CupertinoColors.white,
                        fontSize: 14,
                        fontWeight: FontWeight.w600,
                        decoration: task.isCompleted ? TextDecoration.lineThrough : null,
                      ),
                    ),
                    trailing: task.rolledOver
                        ? Container(
                            padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
                            decoration: BoxDecoration(
                              color: const Color(0x22FFB340),
                              borderRadius: BorderRadius.circular(6),
                            ),
                            child: const Text('Yesterday', style: TextStyle(color: Color(0xFFFFB340), fontSize: 10, fontWeight: FontWeight.w700)),
                          )
                        : null,
                  ),
                );
              }),
            const SizedBox(height: 30),
          ],
        ),
      ),
    );
  }
}
