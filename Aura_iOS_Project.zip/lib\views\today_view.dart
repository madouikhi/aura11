import 'package:flutter/cupertino.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';
import '../models/task.dart';
import '../services/storage_service.dart';
import '../services/location_service.dart';
import 'notes_view.dart';

class TodayView extends StatefulWidget {
  final VoidCallback onOpenNoteEditor;

  const TodayView({super.key, required this.onOpenNoteEditor});

  @override
  State<TodayView> createState() => TodayViewState();
}

class TodayViewState extends State<TodayView> {
  String _location = 'Locating...';
  List<Task> _todayTasks = [];
  String _bedtime = '23:30';
  String _waketime = '07:00';
  String _sleepTotal = '7.5 hrs';

  @override
  void initState() {
    super.initState();
    refresh();
  }

  Future<void> refresh() async {
    final loc = await LocationService.getLocation();
    final tasks = await StorageService.loadTasks();
    final sleep = await StorageService.loadSleepTimes();

    final todayList = tasks.where((t) => t.bucket == 'today').toList();
    // Sort: Fresh tasks first, and Yesterday's unfinished tasks below them!
    todayList.sort((a, b) {
      if (a.rolledOver == b.rolledOver) return 0;
      return a.rolledOver ? 1 : -1;
    });

    if (mounted) {
      setState(() {
        _location = loc;
        _todayTasks = todayList;
        _bedtime = sleep['start'] ?? '23:30';
        _waketime = sleep['end'] ?? '07:00';
        _calcSleep();
      });
    }
  }

  void _calcSleep() {
    try {
      final bParts = _bedtime.split(':').map(int.parse).toList();
      final wParts = _waketime.split(':').map(int.parse).toList();
      int bMinutes = bParts[0] * 60 + bParts[1];
      int wMinutes = wParts[0] * 60 + wParts[1];
      if (wMinutes <= bMinutes) wMinutes += 24 * 60;
      final diffHrs = (wMinutes - bMinutes) / 60.0;
      _sleepTotal = '${diffHrs.toStringAsFixed(1)} hrs';
    } catch (_) {
      _sleepTotal = '7.5 hrs';
    }
  }

  Future<void> _toggleTask(Task task) async {
    HapticFeedback.lightImpact();
    setState(() {
      task.isCompleted = !task.isCompleted;
    });
    final allTasks = await StorageService.loadTasks();
    final idx = allTasks.indexWhere((t) => t.id == task.id);
    if (idx != -1) {
      allTasks[idx] = task;
      await StorageService.saveTasks(allTasks);
    }
  }

  @override
  Widget build(BuildContext context) {
    final now = DateTime.now();
    final dateHeading = DateFormat('EEEE, MMM d').format(now);

    return CupertinoPageScaffold(
      backgroundColor: const Color(0xFF0C0C0E),
      child: SafeArea(
        child: ListView(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
          children: [
            // Top Date & Location Header
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(
                  children: [
                    const Icon(CupertinoIcons.location_solid, size: 12, color: Color(0xFF8E8E93)),
                    const SizedBox(width: 4),
                    Text(
                      _location.toUpperCase(),
                      style: const TextStyle(
                        color: Color(0xFF8E8E93),
                        fontSize: 10,
                        fontWeight: FontWeight.w700,
                        letterSpacing: 0.8,
                      ),
                    ),
                  ],
                ),
                const Text(
                  'TODAY',
                  style: TextStyle(
                    color: Color(0xFF71717A),
                    fontSize: 10,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 1.0,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 4),
            Text(
              dateHeading,
              style: const TextStyle(
                color: CupertinoColors.white,
                fontSize: 26,
                fontWeight: FontWeight.w700,
                letterSpacing: -0.5,
              ),
            ),
            const SizedBox(height: 18),

            // Quick Note Card
            Container(
              decoration: BoxDecoration(
                color: const Color(0xFF131317),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: const Color(0x14FFFFFF)),
              ),
              padding: const EdgeInsets.all(14),
              child: Row(
                children: [
                  Container(
                    width: 36,
                    height: 36,
                    decoration: BoxDecoration(
                      color: const Color(0x1AFFB340),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: const Color(0x33FFB340)),
                    ),
                    alignment: Alignment.center,
                    child: const Icon(CupertinoIcons.pen, size: 16, color: Color(0xFFFFB340)),
                  ),
                  const SizedBox(width: 12),
                  const Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Text('Quick Note', style: TextStyle(color: CupertinoColors.white, fontSize: 13, fontWeight: FontWeight.w700)),
                            SizedBox(width: 6),
                            Text('• MEMO', style: TextStyle(color: Color(0xFFFFB340), fontSize: 9, fontWeight: FontWeight.w700)),
                          ],
                        ),
                        SizedBox(height: 2),
                        Text('Jot down thoughts and reflections', style: TextStyle(color: Color(0xFF71717A), fontSize: 11)),
                      ],
                    ),
                  ),
                  CupertinoButton(
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                    color: CupertinoColors.white,
                    borderRadius: BorderRadius.circular(12),
                    onPressed: widget.onOpenNoteEditor,
                    child: const Text('Write', style: TextStyle(color: CupertinoColors.black, fontSize: 12, fontWeight: FontWeight.w700)),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),

            // Sleep Card
            Container(
              decoration: BoxDecoration(
                color: const Color(0xFF131317),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: const Color(0x14FFFFFF)),
              ),
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Row(
                        children: [
                          Icon(CupertinoIcons.moon_fill, size: 14, color: Color(0xFF8E8E93)),
                          SizedBox(width: 6),
                          Text('SLEEP & ROUTINE', style: TextStyle(color: Color(0xFF8E8E93), fontSize: 11, fontWeight: FontWeight.w700, letterSpacing: 1.0)),
                        ],
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                        decoration: BoxDecoration(
                          color: const Color(0x1FFFFFFF),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Text(_sleepTotal, style: const TextStyle(color: CupertinoColors.white, fontSize: 12, fontWeight: FontWeight.w700)),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      Expanded(
                        child: Container(
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            color: const Color(0xFF1A1A20),
                            borderRadius: BorderRadius.circular(14),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text('Bedtime', style: TextStyle(color: Color(0xFF71717A), fontSize: 11)),
                              const SizedBox(height: 2),
                              Text(_bedtime, style: const TextStyle(color: CupertinoColors.white, fontSize: 15, fontWeight: FontWeight.w700)),
                            ],
                          ),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Container(
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            color: const Color(0xFF1A1A20),
                            borderRadius: BorderRadius.circular(14),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text('Wake Up', style: TextStyle(color: Color(0xFF71717A), fontSize: 11)),
                              const SizedBox(height: 2),
                              Text(_waketime, style: const TextStyle(color: CupertinoColors.white, fontSize: 15, fontWeight: FontWeight.w700)),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),

            // Today Tasks Preview Section
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text('TODAY PRIORITIES', style: TextStyle(color: Color(0xFF71717A), fontSize: 11, fontWeight: FontWeight.w700, letterSpacing: 1.0)),
                Text('${_todayTasks.where((t) => t.isCompleted).length}/${_todayTasks.length} Done', style: const TextStyle(color: Color(0xFF71717A), fontSize: 11)),
              ],
            ),
            const SizedBox(height: 8),

            if (_todayTasks.isEmpty)
              Container(
                decoration: BoxDecoration(
                  color: const Color(0xFF131317),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: const Color(0x14FFFFFF)),
                ),
                padding: const EdgeInsets.all(20),
                alignment: Alignment.center,
                child: const Text('No priorities set for today. Go to Tasks tab to add up to 4.', textAlign: TextAlign.center, style: TextStyle(color: Color(0xFF71717A), fontSize: 12)),
              )
            else
              ..._todayTasks.map((task) {
                return GestureDetector(
                  onTap: () => _toggleTask(task),
                  child: Container(
                    margin: const EdgeInsets.only(bottom: 8),
                    decoration: BoxDecoration(
                      color: const Color(0xFF131317),
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: const Color(0x14FFFFFF)),
                    ),
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 13),
                    child: Row(
                      children: [
                        Icon(
                          task.isCompleted ? CupertinoIcons.check_mark_circled_solid : CupertinoIcons.circle,
                          size: 18,
                          color: task.isCompleted ? const Color(0xFF34C759) : const Color(0xFF71717A),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Text(
                            task.title,
                            style: TextStyle(
                              color: task.isCompleted ? const Color(0xFF71717A) : CupertinoColors.white,
                              fontSize: 13,
                              fontWeight: FontWeight.w500,
                              decoration: task.isCompleted ? TextDecoration.lineThrough : null,
                            ),
                          ),
                        ),
                        if (task.rolledOver)
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                            decoration: BoxDecoration(
                              color: const Color(0x26FF9F0A),
                              borderRadius: BorderRadius.circular(6),
                            ),
                            child: const Text('Yesterday', style: TextStyle(color: Color(0xFFFF9F0A), fontSize: 9, fontWeight: FontWeight.w700)),
                          ),
                      ],
                    ),
                  ),
                );
              }),
          ],
        ),
      ),
    );
  }
}
