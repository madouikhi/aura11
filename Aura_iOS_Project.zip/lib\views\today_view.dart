import 'package:flutter/cupertino.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';
import '../models/task.dart';
import '../state/app_state.dart';
import '../services/storage_service.dart';

class TodayView extends StatelessWidget {
  final VoidCallback onOpenNoteEditor;

  const TodayView({super.key, required this.onOpenNoteEditor});

  void _pickTime(BuildContext context, bool isBedtime) {
    HapticFeedback.selectionClick();
    final currentStr = isBedtime ? appState.bedtime : appState.waketime;
    final parts = currentStr.split(':').map(int.parse).toList();
    final initialDate = DateTime(2026, 1, 1, parts[0], parts[1]);
    DateTime selectedDate = initialDate;

    showCupertinoModalPopup(
      context: context,
      builder: (ctx) => Container(
        height: 280,
        color: const Color(0xFF16161A),
        child: Column(
          children: [
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              decoration: const BoxDecoration(
                border: Border(bottom: BorderSide(color: Color(0x1AFFFFFF), width: 0.5)),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  CupertinoButton(
                    padding: EdgeInsets.zero,
                    child: const Text('Cancel', style: TextStyle(color: Color(0xFF8E8E93), fontSize: 14)),
                    onPressed: () => Navigator.of(ctx).pop(),
                  ),
                  Text(
                    isBedtime ? 'Edit Bedtime' : 'Edit Wake Time',
                    style: const TextStyle(color: CupertinoColors.white, fontSize: 14, fontWeight: FontWeight.w600),
                  ),
                  CupertinoButton(
                    padding: EdgeInsets.zero,
                    child: const Text('Save', style: TextStyle(color: CupertinoColors.white, fontSize: 14, fontWeight: FontWeight.w700)),
                    onPressed: () async {
                      Navigator.of(ctx).pop();
                      HapticFeedback.mediumImpact();
                      final timeStr = DateFormat('HH:mm').format(selectedDate);
                      if (isBedtime) {
                        appState.setSleepTimes(timeStr, appState.waketime);
                      } else {
                        appState.setSleepTimes(appState.bedtime, timeStr);
                      }
                    },
                  ),
                ],
              ),
            ),
            Expanded(
              child: CupertinoDatePicker(
                mode: CupertinoDatePickerMode.time,
                initialDateTime: initialDate,
                use24hFormat: true,
                onDateTimeChanged: (dt) => selectedDate = dt,
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final now = DateTime.now();
    final dateHeading = DateFormat('EEEE, MMM d').format(now);

    return ListenableBuilder(
      listenable: appState,
      builder: (context, _) {
        final todayTasks = appState.tasks.where((t) => t.bucket == 'today').toList();
        todayTasks.sort((a, b) {
          if (a.rolledOver == b.rolledOver) return 0;
          return a.rolledOver ? 1 : -1;
        });

        final completedPrayers = appState.prayers.values.where((v) => v).length;

        return CupertinoPageScaffold(
          backgroundColor: const Color(0xFF0C0C0E),
          child: SafeArea(
            child: ListView(
              physics: const BouncingScrollPhysics(parent: AlwaysScrollableScrollPhysics()),
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
              children: [
                // Top Date & Country Header
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      children: [
                        const Icon(CupertinoIcons.globe, size: 12, color: Color(0xFF8E8E93)),
                        const SizedBox(width: 5),
                        Text(
                          appState.country,
                          style: const TextStyle(
                            color: Color(0xFF8E8E93),
                            fontSize: 10,
                            fontWeight: FontWeight.w700,
                            letterSpacing: 0.8,
                          ),
                        ),
                      ],
                    ),
                    const Text(
                      'TODAY',
                      style: TextStyle(
                        color: Color(0xFF71717A),
                        fontSize: 10,
                        fontWeight: FontWeight.w700,
                        letterSpacing: 1.0,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 4),
                Text(
                  dateHeading,
                  style: const TextStyle(
                    color: CupertinoColors.white,
                    fontSize: 26,
                    fontWeight: FontWeight.w700,
                    letterSpacing: -0.5,
                  ),
                ),
                const SizedBox(height: 18),

                // Quick Note Card
                Container(
                  decoration: BoxDecoration(
                    color: const Color(0xFF131317),
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: const Color(0x14FFFFFF)),
                  ),
                  padding: const EdgeInsets.all(14),
                  child: Row(
                    children: [
                      Container(
                        width: 36,
                        height: 36,
                        decoration: BoxDecoration(
                          color: const Color(0x1AFFB340),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: const Color(0x33FFB340)),
                        ),
                        child: const Icon(CupertinoIcons.square_pencil_fill, size: 18, color: Color(0xFFFFB340)),
                      ),
                      const SizedBox(width: 12),
                      const Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('Quick Note', style: TextStyle(color: CupertinoColors.white, fontSize: 13, fontWeight: FontWeight.w700)),
                            SizedBox(height: 2),
                            Text('Capture sudden thoughts or ideas', style: TextStyle(color: Color(0xFF71717A), fontSize: 11)),
                          ],
                        ),
                      ),
                      CupertinoButton(
                        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                        color: CupertinoColors.white,
                        borderRadius: BorderRadius.circular(12),
                        onPressed: onOpenNoteEditor,
                        child: const Text('Write', style: TextStyle(color: CupertinoColors.black, fontSize: 12, fontWeight: FontWeight.w700)),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 16),

                // Sleep & Routine Card with Dual Independent Bell Icons
                Container(
                  decoration: BoxDecoration(
                    color: const Color(0xFF131317),
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: const Color(0x14FFFFFF)),
                  ),
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    children: [
                      // Header
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          const Row(
                            children: [
                              Icon(CupertinoIcons.moon_fill, size: 14, color: Color(0xFF8E8E93)),
                              SizedBox(width: 6),
                              Text('SLEEP & ROUTINE', style: TextStyle(color: Color(0xFF8E8E93), fontSize: 11, fontWeight: FontWeight.w700, letterSpacing: 1.0)),
                            ],
                          ),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                            decoration: BoxDecoration(
                              color: const Color(0x1FFFFFFF),
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: Text(appState.sleepTotal, style: const TextStyle(color: CupertinoColors.white, fontSize: 12, fontWeight: FontWeight.w700)),
                          ),
                        ],
                      ),
                      const SizedBox(height: 14),

                      // Interactive Bedtime & Wake Up with Independent Pure Bell Icons
                      Row(
                        children: [
                          // Bedtime Box
                          Expanded(
                            child: Container(
                              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                              decoration: BoxDecoration(
                                color: const Color(0xFF1A1A20),
                                borderRadius: BorderRadius.circular(14),
                                border: Border.all(color: const Color(0x14FFFFFF)),
                              ),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  GestureDetector(
                                    onTap: () => _pickTime(context, true),
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        const Text('Bedtime', style: TextStyle(color: Color(0xFF71717A), fontSize: 11)),
                                        const SizedBox(height: 3),
                                        Text(appState.bedtime, style: const TextStyle(color: CupertinoColors.white, fontSize: 16, fontWeight: FontWeight.w700)),
                                      ],
                                    ),
                                  ),
                                  // Pure Bell Icon for Bedtime (No text)
                                  GestureDetector(
                                    onTap: () {
                                      HapticFeedback.lightImpact();
                                      appState.toggleBedAlarm();
                                    },
                                    child: Padding(
                                      padding: const EdgeInsets.all(4),
                                      child: Icon(
                                        appState.bedAlarmEnabled ? CupertinoIcons.bell_fill : CupertinoIcons.bell_slash_fill,
                                        size: 18,
                                        color: appState.bedAlarmEnabled ? const Color(0xFFFFB340) : const Color(0xFF636366),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          const SizedBox(width: 10),

                          // Wake Up Box
                          Expanded(
                            child: Container(
                              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                              decoration: BoxDecoration(
                                color: const Color(0xFF1A1A20),
                                borderRadius: BorderRadius.circular(14),
                                border: Border.all(color: const Color(0x14FFFFFF)),
                              ),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  GestureDetector(
                                    onTap: () => _pickTime(context, false),
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        const Text('Wake Up', style: TextStyle(color: Color(0xFF71717A), fontSize: 11)),
                                        const SizedBox(height: 3),
                                        Text(appState.waketime, style: const TextStyle(color: CupertinoColors.white, fontSize: 16, fontWeight: FontWeight.w700)),
                                      ],
                                    ),
                                  ),
                                  // Pure Bell Icon for Wake Up (No text)
                                  GestureDetector(
                                    onTap: () {
                                      HapticFeedback.lightImpact();
                                      appState.toggleWakeAlarm();
                                    },
                                    child: Padding(
                                      padding: const EdgeInsets.all(4),
                                      child: Icon(
                                        appState.wakeAlarmEnabled ? CupertinoIcons.bell_fill : CupertinoIcons.bell_slash_fill,
                                        size: 18,
                                        color: appState.wakeAlarmEnabled ? const Color(0xFFFFB340) : const Color(0xFF636366),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 16),

                // DAILY PRAYERS SECTION IN TODAY VIEW (CONNECTED IN REAL-TIME TO TASKS)
                Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: const Color(0xFF131317),
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: const Color(0x14FFFFFF)),
                  ),
                  child: Column(
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          const Row(
                            children: [
                              Icon(CupertinoIcons.sparkles, size: 13, color: Color(0xFF5E5CE6)),
                              SizedBox(width: 6),
                              Text(
                                'DAILY PRAYERS',
                                style: TextStyle(
                                  color: Color(0xFF8E8E93),
                                  fontSize: 10,
                                  fontWeight: FontWeight.w700,
                                  letterSpacing: 1.0,
                                ),
                              ),
                            ],
                          ),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                            decoration: BoxDecoration(
                              color: completedPrayers == 5 ? const Color(0x2634C759) : const Color(0x14FFFFFF),
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: Text(
                              '$completedPrayers/5',
                              style: TextStyle(
                                color: completedPrayers == 5 ? const Color(0xFF34C759) : const Color(0xFFA1A1AA),
                                fontSize: 10,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 10),
                      Row(
                        children: StorageService.prayerNames.map((name) {
                          final isDone = appState.prayers[name] ?? false;
                          return Expanded(
                            child: GestureDetector(
                              onTap: () {
                                HapticFeedback.lightImpact();
                                appState.togglePrayer(name);
                              },
                              child: Container(
                                margin: const EdgeInsets.symmetric(horizontal: 2),
                                padding: const EdgeInsets.symmetric(vertical: 8),
                                decoration: BoxDecoration(
                                  color: isDone ? const Color(0x1F34C759) : const Color(0xFF1A1A20),
                                  borderRadius: BorderRadius.circular(12),
                                  border: Border.all(
                                    color: isDone ? const Color(0x8034C759) : const Color(0x14FFFFFF),
                                    width: 1,
                                  ),
                                ),
                                alignment: Alignment.center,
                                child: Column(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    Icon(
                                      isDone ? CupertinoIcons.checkmark_alt : CupertinoIcons.circle,
                                      size: 13,
                                      color: isDone ? const Color(0xFF34C759) : const Color(0xFF52525B),
                                    ),
                                    const SizedBox(height: 3),
                                    Text(
                                      name,
                                      style: TextStyle(
                                        color: isDone ? CupertinoColors.white : const Color(0xFF8E8E93),
                                        fontSize: 11,
                                        fontWeight: isDone ? FontWeight.w700 : FontWeight.w500,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          );
                        }).toList(),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 20),

                // Today Tasks Preview Section
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text('TODAY PRIORITIES', style: TextStyle(color: Color(0xFF71717A), fontSize: 11, fontWeight: FontWeight.w700, letterSpacing: 1.0)),
                    Text('${todayTasks.where((t) => t.isCompleted).length}/${todayTasks.length} Done', style: const TextStyle(color: Color(0xFF71717A), fontSize: 11)),
                  ],
                ),
                const SizedBox(height: 10),

                if (todayTasks.isEmpty)
                  Container(
                    decoration: BoxDecoration(
                      color: const Color(0xFF131317),
                      borderRadius: BorderRadius.circular(18),
                      border: Border.all(color: const Color(0x14FFFFFF)),
                    ),
                    padding: const EdgeInsets.all(22),
                    alignment: Alignment.center,
                    child: const Text('No priorities set for today.\nSwitch to Tasks tab to add up to 4 priorities.',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: Color(0xFF71717A), fontSize: 12, height: 1.4),
                    ),
                  )
                else
                  ...todayTasks.map((task) {
                    return Container(
                      margin: const EdgeInsets.only(bottom: 8),
                      decoration: BoxDecoration(
                        color: const Color(0xFF131317),
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(color: const Color(0x14FFFFFF)),
                      ),
                      child: CupertinoListTile(
                        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                        leading: GestureDetector(
                          onTap: () {
                            HapticFeedback.lightImpact();
                            appState.toggleTask(task);
                          },
                          child: Container(
                            width: 24,
                            height: 24,
                            decoration: BoxDecoration(
                              color: task.isCompleted ? CupertinoColors.white : CupertinoColors.transparent,
                              borderRadius: BorderRadius.circular(8),
                              border: Border.all(
                                color: task.isCompleted ? CupertinoColors.white : const Color(0xFF3F3F46),
                                width: 1.5,
                              ),
                            ),
                            child: task.isCompleted
                                ? const Icon(CupertinoIcons.checkmark, size: 14, color: CupertinoColors.black)
                                : null,
                          ),
                        ),
                        title: Text(
                          task.title,
                          style: TextStyle(
                            color: task.isCompleted ? const Color(0xFF71717A) : CupertinoColors.white,
                            fontSize: 14,
                            fontWeight: FontWeight.w600,
                            decoration: task.isCompleted ? TextDecoration.lineThrough : null,
                          ),
                        ),
                        trailing: task.rolledOver
                            ? Container(
                                padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
                                decoration: BoxDecoration(
                                  color: const Color(0x22FFB340),
                                  borderRadius: BorderRadius.circular(6),
                                ),
                                child: const Text('Yesterday', style: TextStyle(color: Color(0xFFFFB340), fontSize: 10, fontWeight: FontWeight.w700)),
                              )
                            : null,
                      ),
                    );
                  }),
                const SizedBox(height: 30),
              ],
            ),
          ),
        );
      },
    );
  }
}
