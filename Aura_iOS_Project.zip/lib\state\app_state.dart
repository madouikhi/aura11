import 'package:flutter/cupertino.dart';
import 'package:intl/intl.dart';
import '../models/task.dart';
import '../models/note.dart';
import '../models/day_archive.dart';
import '../services/storage_service.dart';
import '../services/location_service.dart';

class AppState extends ChangeNotifier {
  List<Task> tasks = [];
  List<Note> notes = [];
  List<DayArchive> history = [];
  Map<String, bool> prayers = {
    for (final p in StorageService.prayerNames) p: false,
  };
  String bedtime = '23:30';
  String waketime = '07:00';
  String sleepTotal = '7.5 hrs';
  bool bedAlarmEnabled = true;
  bool wakeAlarmEnabled = true;
  String country = 'TÜRKIYE';
  bool isLoading = true;

  Future<void> init() async {
    country = LocationService.syncCountry.toUpperCase();
    await reloadAll();
    isLoading = false;
    notifyListeners();

    // Background silent refresh of country
    LocationService.getLocation().then((c) {
      country = c.toUpperCase();
      notifyListeners();
    });
  }

  Future<void> reloadAll() async {
    tasks = await StorageService.loadTasks();
    notes = await StorageService.loadNotes();
    history = await StorageService.loadHistory();
    prayers = await StorageService.loadTodayPrayers();
    final sleep = await StorageService.loadSleepTimes();
    bedtime = sleep['start'] ?? '23:30';
    waketime = sleep['end'] ?? '07:00';
    bedAlarmEnabled = await StorageService.loadBedAlarmEnabled();
    wakeAlarmEnabled = await StorageService.loadWakeAlarmEnabled();
    _calcSleep();
    notifyListeners();
  }

  void _calcSleep() {
    try {
      final bParts = bedtime.split(':').map(int.parse).toList();
      final wParts = waketime.split(':').map(int.parse).toList();
      int bMinutes = bParts[0] * 60 + bParts[1];
      int wMinutes = wParts[0] * 60 + wParts[1];
      if (wMinutes <= bMinutes) wMinutes += 24 * 60;
      final diffHrs = (wMinutes - bMinutes) / 60.0;
      sleepTotal = '${diffHrs.toStringAsFixed(1)} hrs';
    } catch (_) {
      sleepTotal = '7.5 hrs';
    }
  }

  // --- TASKS ---
  Future<void> addTask(String title, String bucket) async {
    final newTask = Task(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      title: title.trim(),
      bucket: bucket,
    );
    tasks.insert(0, newTask);
    notifyListeners();
    await StorageService.saveTasks(tasks);
  }

  Future<void> toggleTask(Task task) async {
    task.isCompleted = !task.isCompleted;
    notifyListeners();
    await StorageService.saveTasks(tasks);
  }

  Future<void> deleteTask(String id) async {
    tasks.removeWhere((t) => t.id == id);
    notifyListeners();
    await StorageService.saveTasks(tasks);
  }

  Future<void> rescheduleTask(Task task, String newBucket) async {
    task.bucket = newBucket;
    notifyListeners();
    await StorageService.saveTasks(tasks);
  }

  // --- PRAYERS (SYNCHRONIZED EVERYWHERE) ---
  Future<void> togglePrayer(String prayerName) async {
    prayers[prayerName] = !(prayers[prayerName] ?? false);
    notifyListeners();
    await StorageService.saveTodayPrayers(prayers);
  }

  // --- SLEEP & ALARMS ---
  Future<void> setSleepTimes(String newBed, String newWake) async {
    bedtime = newBed;
    waketime = newWake;
    _calcSleep();
    notifyListeners();
    await StorageService.saveSleepTimes(bedtime, waketime);
  }

  Future<void> toggleBedAlarm() async {
    bedAlarmEnabled = !bedAlarmEnabled;
    notifyListeners();
    await StorageService.saveBedAlarmEnabled(bedAlarmEnabled);
  }

  Future<void> toggleWakeAlarm() async {
    wakeAlarmEnabled = !wakeAlarmEnabled;
    notifyListeners();
    await StorageService.saveWakeAlarmEnabled(wakeAlarmEnabled);
  }

  // --- NOTES ---
  Future<void> saveNote(Note note) async {
    final idx = notes.indexWhere((n) => n.id == note.id);
    if (idx != -1) {
      notes[idx] = note;
    } else {
      notes.insert(0, note);
    }
    notifyListeners();
    await StorageService.saveNotes(notes);
  }

  Future<void> toggleArchiveNote(Note note) async {
    note.status = note.status == 'archived' ? 'active' : 'archived';
    notifyListeners();
    await StorageService.saveNotes(notes);
  }

  Future<void> toggleTrashNote(Note note) async {
    if (note.status == 'trash') {
      note.status = 'active';
      note.deletedAt = null;
    } else {
      note.status = 'trash';
      note.deletedAt = DateTime.now();
    }
    notifyListeners();
    await StorageService.saveNotes(notes);
  }

  Future<void> deleteNotePermanently(String noteId) async {
    notes.removeWhere((n) => n.id == noteId);
    notifyListeners();
    await StorageService.saveNotes(notes);
  }

  Future<void> emptyTrash() async {
    notes.removeWhere((n) => n.status == 'trash');
    notifyListeners();
    await StorageService.saveNotes(notes);
  }

  // --- FACTORY RESET (INSTANT PURGE & SYNC) ---
  Future<void> factoryReset() async {
    await StorageService.resetAllData();
    tasks = [];
    notes = [];
    history = [];
    prayers = {for (final p in StorageService.prayerNames) p: false};
    bedtime = '23:30';
    waketime = '07:00';
    bedAlarmEnabled = true;
    wakeAlarmEnabled = true;
    _calcSleep();
    notifyListeners();
  }

  // --- IMPORT BACKUP ---
  Future<bool> importBackup(String jsonStr) async {
    final ok = await StorageService.importAllDataFromJson(jsonStr);
    if (ok) {
      await reloadAll();
    }
    return ok;
  }
}

// Global Singleton for instant zero-latency cross-view access
final appState = AppState();
