import 'dart:convert';
import 'package:flutter/cupertino.dart';
import 'package:flutter/services.dart';
import '../models/task.dart';
import '../models/note.dart';
import '../models/day_archive.dart';
import '../services/supabase_service.dart';
import '../services/storage_service.dart';

class SettingsView extends StatefulWidget {
  final VoidCallback onClose;

  const SettingsView({super.key, required this.onClose});

  @override
  State<SettingsView> createState() => _SettingsViewState();
}

class _SettingsViewState extends State<SettingsView> {
  final TextEditingController _importCtrl = TextEditingController();
  final TextEditingController _urlCtrl = TextEditingController();
  final TextEditingController _keyCtrl = TextEditingController();

  String _statusMsg = 'Local Storage Active';
  bool _isBusy = false;
  int _tasksCount = 0;
  int _notesCount = 0;
  int _historyCount = 0;

  @override
  void initState() {
    super.initState();
    _loadStats();
    _loadCreds();
  }

  Future<void> _loadStats() async {
    final tasks = await StorageService.loadTasks();
    final notes = await StorageService.loadNotes();
    final history = await StorageService.loadHistory();
    if (mounted) {
      setState(() {
        _tasksCount = tasks.length;
        _notesCount = notes.where((n) => n.status != 'trash').length;
        _historyCount = history.length;
      });
    }
  }

  Future<void> _loadCreds() async {
    final url = await SupabaseService.getUrl();
    final key = await SupabaseService.getKey();
    setState(() {
      _urlCtrl.text = url;
      _keyCtrl.text = key;
    });
  }

  Future<void> _exportLocalBackup() async {
    HapticFeedback.mediumImpact();
    final jsonStr = await StorageService.exportAllDataJson();
    await Clipboard.setData(ClipboardData(text: jsonStr));

    setState(() {
      _statusMsg = 'Backup JSON copied to clipboard!';
    });

    if (mounted) {
      showCupertinoDialog(
        context: context,
        builder: (ctx) => CupertinoAlertDialog(
          title: const Text('Local Backup Exported'),
          content: Text(
            'All $_tasksCount tasks, $_notesCount notes, and $_historyCount history days have been packaged into JSON and copied to your clipboard.\n\nYou can paste and save it anywhere safely.',
          ),
          actions: [
            CupertinoDialogAction(
              isDefaultAction: true,
              child: const Text('OK'),
              onPressed: () => Navigator.of(ctx).pop(),
            ),
          ],
        ),
      );
    }
  }

  void _showImportDialog() {
    HapticFeedback.selectionClick();
    _importCtrl.clear();

    showCupertinoDialog(
      context: context,
      builder: (ctx) => CupertinoAlertDialog(
        title: const Text('Import Local Backup'),
        content: Padding(
          padding: const EdgeInsets.only(top: 10),
          child: Column(
            children: [
              const Text('Paste your JSON backup data below to restore all tasks, notes, prayers, and history:'),
              const SizedBox(height: 10),
              CupertinoTextField(
                controller: _importCtrl,
                maxLines: 5,
                placeholder: 'Paste JSON backup here...',
                placeholderStyle: const TextStyle(color: Color(0xFF71717A), fontSize: 12),
                style: const TextStyle(color: CupertinoColors.white, fontSize: 12),
                decoration: BoxDecoration(
                  color: const Color(0xFF2C2C2E),
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
            ],
          ),
        ),
        actions: [
          CupertinoDialogAction(
            isDestructiveAction: true,
            child: const Text('Cancel'),
            onPressed: () => Navigator.of(ctx).pop(),
          ),
          CupertinoDialogAction(
            isDefaultAction: true,
            child: const Text('Restore Data'),
            onPressed: () async {
              final raw = _importCtrl.text.trim();
              if (raw.isEmpty) return;
              Navigator.of(ctx).pop();

              final success = await StorageService.importAllDataFromJson(raw);
              HapticFeedback.mediumImpact();
              if (success) {
                await _loadStats();
                setState(() => _statusMsg = 'Data restored successfully!');
                if (mounted) {
                  showCupertinoDialog(
                    context: context,
                    builder: (c) => CupertinoAlertDialog(
                      title: const Text('Restore Complete'),
                      content: const Text('All data has been restored safely to local storage.'),
                      actions: [
                        CupertinoDialogAction(
                          child: const Text('OK'),
                          onPressed: () => Navigator.of(c).pop(),
                        ),
                      ],
                    ),
                  );
                }
              } else {
                setState(() => _statusMsg = 'Error: Invalid JSON backup format');
              }
            },
          ),
        ],
      ),
    );
  }

  Future<void> _resetAllDataConfirm() async {
    HapticFeedback.heavyImpact();
    showCupertinoDialog(
      context: context,
      builder: (ctx) => CupertinoAlertDialog(
        title: const Text('Reset All Data?'),
        content: const Text(
          'This will permanently delete all tasks, notes, prayers, sleep settings, and history archives, returning the app to a clean fresh start. This action cannot be undone.',
        ),
        actions: [
          CupertinoDialogAction(
            isDefaultAction: true,
            child: const Text('Cancel'),
            onPressed: () => Navigator.of(ctx).pop(),
          ),
          CupertinoDialogAction(
            isDestructiveAction: true,
            child: const Text('Reset Everything'),
            onPressed: () async {
              Navigator.of(ctx).pop();
              await StorageService.resetAllData();
              HapticFeedback.heavyImpact();
              await _loadStats();
              setState(() {
                _statusMsg = 'App reset to initial clean state';
              });
              if (mounted) {
                showCupertinoDialog(
                  context: context,
                  builder: (c) => CupertinoAlertDialog(
                    title: const Text('Reset Complete'),
                    content: const Text('All data has been cleared. You now have a fresh clean start.'),
                    actions: [
                      CupertinoDialogAction(
                        child: const Text('OK'),
                        onPressed: () => Navigator.of(c).pop(),
                      ),
                    ],
                  ),
                );
              }
            },
          ),
        ],
      ),
    );
  }

  Future<void> _pushToCloud() async {
    setState(() {
      _isBusy = true;
      _statusMsg = 'Pushing to cloud...';
    });
    await SupabaseService.saveCredentials(_urlCtrl.text, _keyCtrl.text);

    final tasks = await StorageService.loadTasks();
    final notes = await StorageService.loadNotes();
    final history = await StorageService.loadHistory();
    final sleep = await StorageService.loadSleepTimes();
    final prayers = await StorageService.loadTodayPrayers();

    final payload = {
      'tasks': tasks.map((t) => t.toJson()).toList(),
      'notes': notes.map((n) => n.toJson()).toList(),
      'timeline': history.map((h) => h.toJson()).toList(),
      'sleep': sleep,
      'prayers': prayers,
    };

    final ok = await SupabaseService.pushBackup(payload);
    HapticFeedback.mediumImpact();
    setState(() {
      _isBusy = false;
      _statusMsg = ok ? 'Cloud Backup Successful' : 'Failed to connect to Supabase';
    });
  }

  Future<void> _pullFromCloud() async {
    setState(() {
      _isBusy = true;
      _statusMsg = 'Pulling from cloud...';
    });
    await SupabaseService.saveCredentials(_urlCtrl.text, _keyCtrl.text);

    final data = await SupabaseService.pullBackup();
    HapticFeedback.mediumImpact();

    if (data != null) {
      if (data['tasks'] != null) {
        final list = (data['tasks'] as List<dynamic>)
            .map((e) => Task.fromJson(Map<String, dynamic>.from(e as Map)))
            .toList();
        await StorageService.saveTasks(list);
      }
      if (data['notes'] != null) {
        final list = (data['notes'] as List<dynamic>)
            .map((e) => Note.fromJson(Map<String, dynamic>.from(e as Map)))
            .toList();
        await StorageService.saveNotes(list);
      }
      if (data['timeline'] != null) {
        final list = (data['timeline'] as List<dynamic>)
            .map((e) => DayArchive.fromJson(Map<String, dynamic>.from(e as Map)))
            .toList();
        await StorageService.saveHistory(list);
      }
      if (data['sleep'] != null) {
        final sleepMap = Map<String, dynamic>.from(data['sleep'] as Map);
        await StorageService.saveSleepTimes(
          sleepMap['start']?.toString() ?? '23:30',
          sleepMap['end']?.toString() ?? '07:00',
        );
      }
      if (data['prayers'] != null) {
        final pmap = Map<String, dynamic>.from(data['prayers'] as Map);
        final Map<String, bool> prayers = {};
        for (final p in StorageService.prayerNames) {
          prayers[p] = pmap[p] == true;
        }
        await StorageService.saveTodayPrayers(prayers);
      }
      await _loadStats();
      setState(() {
        _isBusy = false;
        _statusMsg = 'Cloud Data Restored';
      });
    } else {
      setState(() {
        _isBusy = false;
        _statusMsg = 'No backup found or connection error';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return CupertinoPageScaffold(
      backgroundColor: const Color(0xFF0C0C0E),
      navigationBar: CupertinoNavigationBar(
        backgroundColor: const Color(0xFF0C0C0E).withOpacity(0.9),
        border: const Border(bottom: BorderSide(color: Color(0x1AFFFFFF))),
        leading: CupertinoButton(
          padding: EdgeInsets.zero,
          onPressed: widget.onClose,
          child: const Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(CupertinoIcons.chevron_left, size: 18, color: CupertinoColors.white),
              SizedBox(width: 4),
              Text('Done', style: TextStyle(color: CupertinoColors.white, fontSize: 14, fontWeight: FontWeight.w600)),
            ],
          ),
        ),
        middle: const Text(
          'PREFERENCES',
          style: TextStyle(
            color: Color(0xFF8E8E93),
            fontSize: 11,
            letterSpacing: 1.2,
            fontWeight: FontWeight.w600,
          ),
        ),
      ),
      child: SafeArea(
        child: ListView(
          physics: const BouncingScrollPhysics(),
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
          children: [
            // App Branding & Local Persistence Badge
            Container(
              decoration: BoxDecoration(
                color: const Color(0xFF131317),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: const Color(0x14FFFFFF)),
              ),
              padding: const EdgeInsets.all(18),
              child: Column(
                children: [
                  Row(
                    children: [
                      ClipRRect(
                        borderRadius: BorderRadius.circular(14),
                        child: Image.asset(
                          'assets/app_logo.png',
                          width: 46,
                          height: 46,
                          fit: BoxFit.cover,
                          errorBuilder: (_, __, ___) => Container(
                            width: 46,
                            height: 46,
                            decoration: BoxDecoration(
                              color: const Color(0xFF1C1C1E),
                              borderRadius: BorderRadius.circular(14),
                            ),
                            child: const Icon(CupertinoIcons.sparkles, color: CupertinoColors.white),
                          ),
                        ),
                      ),
                      const SizedBox(width: 14),
                      const Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('AURA', style: TextStyle(color: CupertinoColors.white, fontSize: 18, fontWeight: FontWeight.w800, letterSpacing: 1.0)),
                          SizedBox(height: 2),
                          Text('Minimalist iOS Organizer', style: TextStyle(color: Color(0xFF8E8E93), fontSize: 12)),
                        ],
                      ),
                    ],
                  ),
                  const SizedBox(height: 14),
                  // Storage health counters
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                    decoration: BoxDecoration(
                      color: const Color(0xFF1A1A20),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        _buildStatCol('Tasks', '$_tasksCount'),
                        _buildDivider(),
                        _buildStatCol('Notes', '$_notesCount'),
                        _buildDivider(),
                        _buildStatCol('Archives', '$_historyCount'),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),

            // PRIMARY SECTION: LOCAL DATA BACKUP & RESTORE (OFFLINE)
            const Text(
              'LOCAL DATA BACKUP (NO CLOUD NEEDED)',
              style: TextStyle(color: Color(0xFF71717A), fontSize: 10, fontWeight: FontWeight.w700, letterSpacing: 1.0),
            ),
            const SizedBox(height: 8),
            Container(
              decoration: BoxDecoration(
                color: const Color(0xFF131317),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: const Color(0x14FFFFFF)),
              ),
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Export or restore your data entirely on your device without relying on internet or external servers.',
                    style: TextStyle(color: Color(0xFF8E8E93), fontSize: 12, height: 1.4),
                  ),
                  const SizedBox(height: 14),
                  Row(
                    children: [
                      // Export Button
                      Expanded(
                        child: CupertinoButton(
                          padding: const EdgeInsets.symmetric(vertical: 12),
                          color: CupertinoColors.white,
                          borderRadius: BorderRadius.circular(14),
                          onPressed: _exportLocalBackup,
                          child: const Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(CupertinoIcons.doc_on_clipboard, size: 15, color: CupertinoColors.black),
                              SizedBox(width: 6),
                              Text('Export Backup', style: TextStyle(color: CupertinoColors.black, fontSize: 12, fontWeight: FontWeight.w700)),
                            ],
                          ),
                        ),
                      ),
                      const SizedBox(width: 10),
                      // Import Button
                      Expanded(
                        child: CupertinoButton(
                          padding: const EdgeInsets.symmetric(vertical: 12),
                          color: const Color(0xFF27272A),
                          borderRadius: BorderRadius.circular(14),
                          onPressed: _showImportDialog,
                          child: const Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(CupertinoIcons.arrow_down_doc, size: 15, color: CupertinoColors.white),
                              SizedBox(width: 6),
                              Text('Import Backup', style: TextStyle(color: CupertinoColors.white, fontSize: 12, fontWeight: FontWeight.w700)),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),

            // STATUS FEEDBACK
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
              decoration: BoxDecoration(
                color: const Color(0xFF131317),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: const Color(0x14FFFFFF)),
              ),
              child: Row(
                children: [
                  Icon(
                    _isBusy ? CupertinoIcons.arrow_2_circlepath : CupertinoIcons.checkmark_shield_fill,
                    size: 14,
                    color: _isBusy ? const Color(0xFFFF9F0A) : const Color(0xFF34C759),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      _statusMsg,
                      style: const TextStyle(color: Color(0xFFA1A1AA), fontSize: 11, fontWeight: FontWeight.w500),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),

            // DANGER ZONE / FACTORY RESET
            const Text(
              'RESET & FRESH START',
              style: TextStyle(color: Color(0xFF71717A), fontSize: 10, fontWeight: FontWeight.w700, letterSpacing: 1.0),
            ),
            const SizedBox(height: 8),
            Container(
              decoration: BoxDecoration(
                color: const Color(0xFF131317),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: const Color(0x26FF453A)),
              ),
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Clear all tasks, notes, prayers, and history to start over completely.',
                    style: TextStyle(color: Color(0xFF8E8E93), fontSize: 12),
                  ),
                  const SizedBox(height: 12),
                  CupertinoButton(
                    padding: const EdgeInsets.symmetric(vertical: 12),
                    color: const Color(0x26FF453A),
                    borderRadius: BorderRadius.circular(14),
                    onPressed: _resetAllDataConfirm,
                    child: const Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(CupertinoIcons.trash_fill, size: 14, color: Color(0xFFFF453A)),
                        SizedBox(width: 6),
                        Text('Reset All Data & Start Fresh', style: TextStyle(color: Color(0xFFFF453A), fontSize: 12, fontWeight: FontWeight.w700)),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),

            // OPTIONAL CLOUD SYNC SECTION (SUPABASE)
            const Text(
              'OPTIONAL CLOUD SYNC',
              style: TextStyle(color: Color(0xFF71717A), fontSize: 10, fontWeight: FontWeight.w700, letterSpacing: 1.0),
            ),
            const SizedBox(height: 8),
            Container(
              decoration: BoxDecoration(
                color: const Color(0xFF131317),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: const Color(0x14FFFFFF)),
              ),
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  CupertinoTextField(
                    controller: _urlCtrl,
                    placeholder: 'Supabase URL',
                    placeholderStyle: const TextStyle(color: Color(0xFF52525B), fontSize: 12),
                    style: const TextStyle(color: CupertinoColors.white, fontSize: 12),
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                    decoration: BoxDecoration(
                      color: const Color(0xFF1A1A20),
                      borderRadius: BorderRadius.circular(10),
                    ),
                  ),
                  const SizedBox(height: 8),
                  CupertinoTextField(
                    controller: _keyCtrl,
                    placeholder: 'Supabase Anon Key',
                    obscureText: true,
                    placeholderStyle: const TextStyle(color: Color(0xFF52525B), fontSize: 12),
                    style: const TextStyle(color: CupertinoColors.white, fontSize: 12),
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                    decoration: BoxDecoration(
                      color: const Color(0xFF1A1A20),
                      borderRadius: BorderRadius.circular(10),
                    ),
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      Expanded(
                        child: CupertinoButton(
                          padding: const EdgeInsets.symmetric(vertical: 10),
                          color: const Color(0xFF27272A),
                          borderRadius: BorderRadius.circular(12),
                          onPressed: _isBusy ? null : _pushToCloud,
                          child: const Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(CupertinoIcons.cloud_upload, size: 14, color: CupertinoColors.white),
                              SizedBox(width: 6),
                              Text('Push Cloud', style: TextStyle(color: CupertinoColors.white, fontSize: 11, fontWeight: FontWeight.w600)),
                            ],
                          ),
                        ),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: CupertinoButton(
                          padding: const EdgeInsets.symmetric(vertical: 10),
                          color: const Color(0xFF27272A),
                          borderRadius: BorderRadius.circular(12),
                          onPressed: _isBusy ? null : _pullFromCloud,
                          child: const Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(CupertinoIcons.cloud_download, size: 14, color: CupertinoColors.white),
                              SizedBox(width: 6),
                              Text('Pull Cloud', style: TextStyle(color: CupertinoColors.white, fontSize: 11, fontWeight: FontWeight.w600)),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 40),
          ],
        ),
      ),
    );
  }

  Widget _buildStatCol(String label, String count) {
    return Column(
      children: [
        Text(count, style: const TextStyle(color: CupertinoColors.white, fontSize: 15, fontWeight: FontWeight.w700)),
        const SizedBox(height: 1),
        Text(label, style: const TextStyle(color: Color(0xFF71717A), fontSize: 10)),
      ],
    );
  }

  Widget _buildDivider() {
    return Container(width: 1, height: 24, color: const Color(0x1FFFFFFF));
  }
}
