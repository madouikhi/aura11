import 'dart:convert';
import 'package:flutter/cupertino.dart';
import 'package:flutter/services.dart';
import '../models/task.dart';
import '../models/note.dart';
import '../models/day_archive.dart';
import '../services/supabase_service.dart';
import '../services/storage_service.dart';

class SettingsView extends StatefulWidget {
  final VoidCallback onClose;

  const SettingsView({super.key, required this.onClose});

  @override
  State<SettingsView> createState() => _SettingsViewState();
}

class _SettingsViewState extends State<SettingsView> {
  final TextEditingController _urlCtrl = TextEditingController();
  final TextEditingController _keyCtrl = TextEditingController();
  String _statusMsg = 'Ready';
  bool _isBusy = false;

  @override
  void initState() {
    super.initState();
    _loadCreds();
  }

  Future<void> _loadCreds() async {
    final url = await SupabaseService.getUrl();
    final key = await SupabaseService.getKey();
    setState(() {
      _urlCtrl.text = url;
      _keyCtrl.text = key;
    });
  }

  Future<void> _saveCreds() async {
    await SupabaseService.saveCredentials(_urlCtrl.text, _keyCtrl.text);
    HapticFeedback.lightImpact();
    setState(() => _statusMsg = 'Credentials saved');
  }

  Future<void> _pushToCloud() async {
    setState(() {
      _isBusy = true;
      _statusMsg = 'Pushing to cloud...';
    });
    await _saveCreds();

    final tasks = await StorageService.loadTasks();
    final notes = await StorageService.loadNotes();
    final history = await StorageService.loadHistory();
    final sleep = await StorageService.loadSleepTimes();

    final payload = {
      'tasks': tasks.map((t) => t.toJson()).toList(),
      'notes': notes.map((n) => n.toJson()).toList(),
      'timeline': history.map((h) => h.toJson()).toList(),
      'sleep': sleep,
    };

    final ok = await SupabaseService.pushBackup(payload);
    HapticFeedback.mediumImpact();
    setState(() {
      _isBusy = false;
      _statusMsg = ok ? 'Cloud Backup Successful' : 'Failed to connect to Supabase';
    });
  }

  Future<void> _pullFromCloud() async {
    setState(() {
      _isBusy = true;
      _statusMsg = 'Pulling from cloud...';
    });
    await _saveCreds();

    final data = await SupabaseService.pullBackup();
    HapticFeedback.mediumImpact();

    if (data != null) {
      if (data['tasks'] != null) {
        final list = (data['tasks'] as List<dynamic>)
            .map((e) => Task.fromJson(Map<String, dynamic>.from(e as Map)))
            .toList();
        await StorageService.saveTasks(list);
      }
      if (data['notes'] != null) {
        final list = (data['notes'] as List<dynamic>)
            .map((e) => Note.fromJson(Map<String, dynamic>.from(e as Map)))
            .toList();
        await StorageService.saveNotes(list);
      }
      if (data['timeline'] != null) {
        final list = (data['timeline'] as List<dynamic>)
            .map((e) => DayArchive.fromJson(Map<String, dynamic>.from(e as Map)))
            .toList();
        await StorageService.saveHistory(list);
      }
      if (data['sleep'] != null) {
        final sleepMap = Map<String, dynamic>.from(data['sleep'] as Map);
        await StorageService.saveSleepTimes(
          sleepMap['start']?.toString() ?? '23:30',
          sleepMap['end']?.toString() ?? '07:00',
        );
      }
      setState(() {
        _isBusy = false;
        _statusMsg = 'Cloud Data Restored';
      });
    } else {
      setState(() {
        _isBusy = false;
        _statusMsg = 'No backup found or connection error';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return CupertinoPageScaffold(
      backgroundColor: const Color(0xFF0C0C0E),
      navigationBar: CupertinoNavigationBar(
        backgroundColor: const Color(0xFF0C0C0E).withOpacity(0.9),
        border: const Border(bottom: BorderSide(color: Color(0x1AFFFFFF))),
        leading: CupertinoButton(
          padding: EdgeInsets.zero,
          onPressed: widget.onClose,
          child: const Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(CupertinoIcons.chevron_left, size: 18, color: CupertinoColors.white),
              SizedBox(width: 4),
              Text('Back', style: TextStyle(color: CupertinoColors.white, fontSize: 14)),
            ],
          ),
        ),
        middle: const Text(
          'PREFERENCES',
          style: TextStyle(
            color: Color(0xFF8E8E93),
            fontSize: 11,
            letterSpacing: 1.2,
            fontWeight: FontWeight.w600,
          ),
        ),
      ),
      child: SafeArea(
        child: ListView(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
          children: [
            // Branding
            Row(
              children: [
                ClipRRect(
                  borderRadius: BorderRadius.circular(12),
                  child: Image.asset('assets/app_logo.png', width: 44, height: 44, fit: BoxFit.cover),
                ),
                const SizedBox(width: 12),
                const Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Settings', style: TextStyle(color: CupertinoColors.white, fontSize: 20, fontWeight: FontWeight.w700)),
                    SizedBox(height: 2),
                    Text('Aura LifeLog • Pure Native iOS', style: TextStyle(color: Color(0xFF71717A), fontSize: 11)),
                  ],
                ),
              ],
            ),
            const SizedBox(height: 24),

            // Cloud Sync Section
            const Text('CLOUD SYNC (SUPABASE)', style: TextStyle(color: Color(0xFF71717A), fontSize: 11, fontWeight: FontWeight.w700, letterSpacing: 1.0)),
            const SizedBox(height: 8),
            Container(
              decoration: BoxDecoration(
                color: const Color(0xFF131317),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: const Color(0x14FFFFFF)),
              ),
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('PROJECT URL', style: TextStyle(color: Color(0xFF71717A), fontSize: 10, fontWeight: FontWeight.w600)),
                  const SizedBox(height: 6),
                  CupertinoTextField(
                    controller: _urlCtrl,
                    style: const TextStyle(color: CupertinoColors.white, fontSize: 12),
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                    decoration: BoxDecoration(
                      color: const Color(0xFF1A1A20),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: const Color(0x14FFFFFF)),
                    ),
                  ),
                  const SizedBox(height: 12),

                  const Text('API KEY (PUBLISHABLE)', style: TextStyle(color: Color(0xFF71717A), fontSize: 10, fontWeight: FontWeight.w600)),
                  const SizedBox(height: 6),
                  CupertinoTextField(
                    controller: _keyCtrl,
                    obscureText: true,
                    style: const TextStyle(color: CupertinoColors.white, fontSize: 12),
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                    decoration: BoxDecoration(
                      color: const Color(0xFF1A1A20),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: const Color(0x14FFFFFF)),
                    ),
                  ),
                  const SizedBox(height: 14),

                  Row(
                    children: [
                      Expanded(
                        child: CupertinoButton(
                          padding: const EdgeInsets.symmetric(vertical: 11),
                          color: CupertinoColors.white,
                          borderRadius: BorderRadius.circular(12),
                          onPressed: _isBusy ? null : _pushToCloud,
                          child: const Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(CupertinoIcons.cloud_upload, size: 14, color: CupertinoColors.black),
                              SizedBox(width: 6),
                              Text('Push to Cloud', style: TextStyle(color: CupertinoColors.black, fontSize: 12, fontWeight: FontWeight.w700)),
                            ],
                          ),
                        ),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: CupertinoButton(
                          padding: const EdgeInsets.symmetric(vertical: 11),
                          color: const Color(0x1FFFFFFF),
                          borderRadius: BorderRadius.circular(12),
                          onPressed: _isBusy ? null : _pullFromCloud,
                          child: const Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(CupertinoIcons.cloud_download, size: 14, color: CupertinoColors.white),
                              SizedBox(width: 6),
                              Text('Pull from Cloud', style: TextStyle(color: CupertinoColors.white, fontSize: 12, fontWeight: FontWeight.w600)),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 10),

                  Center(
                    child: Text(
                      'Status: $_statusMsg',
                      style: const TextStyle(color: Color(0xFFA1A1AA), fontSize: 11),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
