class Note {
  final String id;
  String title;
  String body;
  String status; // 'active', 'archived', 'trash'
  String color; // 'default', 'amber', 'emerald', 'blue', 'purple', 'rose'
  DateTime updatedAt;
  DateTime? deletedAt;

  Note({
    required this.id,
    required this.title,
    required this.body,
    this.status = 'active',
    this.color = 'default',
    DateTime? updatedAt,
    this.deletedAt,
  }) : updatedAt = updatedAt ?? DateTime.now();

  Map<String, dynamic> toJson() => {
    'id': id,
    'title': title,
    'body': body,
    'status': status,
    'color': color,
    'updatedAt': updatedAt.toIso8601String(),
    'deletedAt': deletedAt?.toIso8601String(),
  };

  factory Note.fromJson(Map<String, dynamic> json) {
    String st = json['status'] ?? 'active';
    if (json['folder'] != null && json['status'] == null) {
      st = json['folder'] == 'archived' ? 'archived' : 'active';
    }

    return Note(
      id: json['id'].toString(),
      title: json['title'] ?? '',
      body: json['body'] ?? '',
      status: st,
      color: json['color'] ?? 'default',
      updatedAt: json['updatedAt'] != null
          ? DateTime.tryParse(json['updatedAt']) ?? DateTime.now()
          : DateTime.now(),
      deletedAt: json['deletedAt'] != null
          ? DateTime.tryParse(json['deletedAt'])
          : null,
    );
  }
}
