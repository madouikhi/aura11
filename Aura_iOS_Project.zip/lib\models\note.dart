class Note {
  final String id;
  String title;
  String body;
  String folder;
  String color;
  DateTime updatedAt;

  Note({
    required this.id,
    required this.title,
    required this.body,
    this.folder = 'all',
    this.color = 'default',
    DateTime? updatedAt,
  }) : updatedAt = updatedAt ?? DateTime.now();

  Map<String, dynamic> toJson() => {
    'id': id,
    'title': title,
    'body': body,
    'folder': folder,
    'color': color,
    'updatedAt': updatedAt.toIso8601String(),
  };

  factory Note.fromJson(Map<String, dynamic> json) => Note(
    id: json['id'].toString(),
    title: json['title'] ?? '',
    body: json['body'] ?? '',
    folder: json['folder'] ?? 'all',
    color: json['color'] ?? 'default',
    updatedAt: json['updatedAt'] != null
        ? DateTime.tryParse(json['updatedAt']) ?? DateTime.now()
        : DateTime.now(),
  );
}
