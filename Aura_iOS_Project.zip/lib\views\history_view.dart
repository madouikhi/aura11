import 'package:flutter/cupertino.dart';
import 'package:intl/intl.dart';
import '../models/day_archive.dart';
import '../state/app_state.dart';
import 'day_detail_view.dart';

class HistoryView extends StatelessWidget {
  const HistoryView({super.key});

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: appState,
      builder: (context, _) {
        final history = appState.history;

        // Calculate average discipline score across recorded days
        double totalScore = 0;
        for (final day in history) {
          totalScore += day.disciplineScore;
        }
        final avgScore = history.isNotEmpty ? (totalScore / history.length).round() : 100;

        return CupertinoPageScaffold(
          backgroundColor: const Color(0xFF0C0C0E),
          child: SafeArea(
            child: ListView(
              physics: const BouncingScrollPhysics(),
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
              children: [
                // Header
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'SMART ARCHIVE',
                          style: TextStyle(
                            color: Color(0xFF71717A),
                            fontSize: 11,
                            fontWeight: FontWeight.w700,
                            letterSpacing: 1.0,
                          ),
                        ),
                        SizedBox(height: 2),
                        Text(
                          'Daily History',
                          style: TextStyle(
                            color: CupertinoColors.white,
                            fontSize: 26,
                            fontWeight: FontWeight.w700,
                            letterSpacing: -0.5,
                          ),
                        ),
                      ],
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                      decoration: BoxDecoration(
                        color: const Color(0x14FFFFFF),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Text(
                        '${history.length} Days',
                        style: const TextStyle(color: Color(0xFFA1A1AA), fontSize: 11, fontWeight: FontWeight.w600),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 16),

                // DISCIPLINE & CONSISTENCY CHART (مبيان الانضباط)
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: const Color(0xFF131317),
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: const Color(0x14FFFFFF)),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          const Row(
                            children: [
                              Icon(CupertinoIcons.chart_bar_alt_fill, size: 14, color: Color(0xFF34C759)),
                              SizedBox(width: 6),
                              Text(
                                'DISCIPLINE & CONSISTENCY',
                                style: TextStyle(
                                  color: Color(0xFF8E8E93),
                                  fontSize: 10,
                                  fontWeight: FontWeight.w700,
                                  letterSpacing: 1.0,
                                ),
                              ),
                            ],
                          ),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                            decoration: BoxDecoration(
                              color: const Color(0x2634C759),
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: Text(
                              '$avgScore% Score',
                              style: const TextStyle(
                                color: Color(0xFF34C759),
                                fontSize: 10,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 16),

                      // 7-Day Consistency Bars
                      _buildWeeklyBarChart(history),
                    ],
                  ),
                ),
                const SizedBox(height: 20),

                const Text(
                  'PAST DAYS ARCHIVE',
                  style: TextStyle(
                    color: Color(0xFF71717A),
                    fontSize: 10,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 1.0,
                  ),
                ),
                const SizedBox(height: 10),

                if (history.isEmpty)
                  Container(
                    decoration: BoxDecoration(
                      color: const Color(0xFF131317),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: const Color(0x14FFFFFF)),
                    ),
                    padding: const EdgeInsets.all(28),
                    alignment: Alignment.center,
                    child: const Text(
                      'No archived history yet.\nEach finished day will appear here automatically with full tasks, prayers, and sleep data.',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: Color(0xFF71717A), fontSize: 13, height: 1.4),
                    ),
                  )
                else
                  ...history.map((day) {
                    final score = day.disciplineScore.round();
                    return GestureDetector(
                      onTap: () {
                        Navigator.of(context).push(
                          CupertinoPageRoute(
                            builder: (_) => DayDetailView(archive: day),
                          ),
                        );
                      },
                      child: Container(
                        margin: const EdgeInsets.only(bottom: 10),
                        decoration: BoxDecoration(
                          color: const Color(0xFF131317),
                          borderRadius: BorderRadius.circular(18),
                          border: Border.all(color: const Color(0x14FFFFFF)),
                        ),
                        padding: const EdgeInsets.all(16),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text(
                                  day.date,
                                  style: const TextStyle(
                                    color: CupertinoColors.white,
                                    fontSize: 16,
                                    fontWeight: FontWeight.w700,
                                  ),
                                ),
                                Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                                  decoration: BoxDecoration(
                                    color: score >= 80 ? const Color(0x2234C759) : const Color(0x22FFB340),
                                    borderRadius: BorderRadius.circular(8),
                                  ),
                                  child: Text(
                                    '$score% Discipline',
                                    style: TextStyle(
                                      color: score >= 80 ? const Color(0xFF34C759) : const Color(0xFFFFB340),
                                      fontSize: 10,
                                      fontWeight: FontWeight.w700,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 8),
                            Row(
                              children: [
                                // Tasks indicator
                                Row(
                                  children: [
                                    const Icon(CupertinoIcons.checkmark_circle_fill, size: 12, color: Color(0xFF8E8E93)),
                                    const SizedBox(width: 4),
                                    Text(
                                      '${day.tasksDone}/${day.tasksTotal} Tasks',
                                      style: const TextStyle(color: Color(0xFF8E8E93), fontSize: 11),
                                    ),
                                  ],
                                ),
                                const SizedBox(width: 14),
                                // Prayers indicator
                                Row(
                                  children: [
                                    const Icon(CupertinoIcons.sparkles, size: 12, color: Color(0xFF5E5CE6)),
                                    const SizedBox(width: 4),
                                    Text(
                                      '${day.prayersDone}/5 Prayers',
                                      style: const TextStyle(color: Color(0xFF8E8E93), fontSize: 11),
                                    ),
                                  ],
                                ),
                                const SizedBox(width: 14),
                                // Sleep indicator
                                Row(
                                  children: [
                                    const Icon(CupertinoIcons.moon_fill, size: 12, color: Color(0xFF8E8E93)),
                                    const SizedBox(width: 4),
                                    Text(
                                      day.sleepHours,
                                      style: const TextStyle(color: Color(0xFF8E8E93), fontSize: 11),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    );
                  }),
                const SizedBox(height: 20),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildWeeklyBarChart(List<DayArchive> history) {
    // Generate 7 days labels (Monday - Sunday or last 7 days)
    final now = DateTime.now();
    final List<Map<String, dynamic>> barDays = [];

    for (int i = 6; i >= 0; i--) {
      final date = now.subtract(Duration(days: i));
      final dateFormatted = DateFormat('MMM d, yyyy').format(date);
      final dayLetter = DateFormat('E').format(date).substring(0, 1);

      // Find matching archive
      final archive = history.firstWhere(
        (a) => a.date == dateFormatted,
        orElse: () => DayArchive(
          id: '',
          date: '',
          location: '',
          sleepHours: '',
          bedtime: '',
          waketime: '',
          tasksDone: 0,
          tasksTotal: 4,
          tasks: [],
          notes: [],
          prayersDone: 0,
        ),
      );

      final double score = archive.id.isNotEmpty ? archive.disciplineScore : 0.0;
      barDays.add({
        'day': dayLetter,
        'score': score,
        'hasData': archive.id.isNotEmpty,
      });
    }

    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      crossAxisAlignment: CrossAxisAlignment.end,
      children: barDays.map((b) {
        final double score = b['score'] as double;
        final String day = b['day'] as String;
        final bool hasData = b['hasData'] as bool;
        final double barHeight = hasData ? (score * 0.55).clamp(8.0, 55.0) : 6.0;

        Color barColor = const Color(0xFF1E1E24);
        if (hasData) {
          if (score >= 80) {
            barColor = const Color(0xFF34C759);
          } else if (score >= 50) {
            barColor = const Color(0xFFFFB340);
          } else {
            barColor = const Color(0xFF5E5CE6);
          }
        }

        return Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              hasData ? '${score.round()}%' : '-',
              style: TextStyle(
                color: hasData ? const Color(0xFFA1A1AA) : const Color(0xFF3F3F46),
                fontSize: 9,
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 6),
            Container(
              width: 26,
              height: barHeight,
              decoration: BoxDecoration(
                color: barColor,
                borderRadius: BorderRadius.circular(6),
              ),
            ),
            const SizedBox(height: 6),
            Text(
              day,
              style: const TextStyle(
                color: Color(0xFF71717A),
                fontSize: 10,
                fontWeight: FontWeight.w700,
              ),
            ),
          ],
        );
      }).toList(),
    );
  }
}
