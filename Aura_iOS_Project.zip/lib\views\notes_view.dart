import 'package:flutter/cupertino.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';
import '../models/note.dart';
import '../services/storage_service.dart';

class NotesView extends StatefulWidget {
  const NotesView({super.key});

  @override
  State<NotesView> createState() => NotesViewState();
}

class NotesViewState extends State<NotesView> {
  List<Note> _notes = [];
  String _selectedFolder = 'all';

  @override
  void initState() {
    super.initState();
    refresh();
  }

  Future<void> refresh() async {
    final list = await StorageService.loadNotes();
    if (mounted) setState(() => _notes = list);
  }

  void openEditor([Note? existing]) {
    Navigator.of(context).push(
      CupertinoPageRoute(
        builder: (_) => NoteEditorScreen(
          note: existing,
          onSave: (saved) async {
            if (existing != null) {
              final idx = _notes.indexWhere((n) => n.id == existing.id);
              if (idx != -1) _notes[idx] = saved;
            } else {
              _notes.insert(0, saved);
            }
            setState(() {});
            await StorageService.saveNotes(_notes);
          },
          onDelete: existing != null
              ? () async {
                  _notes.removeWhere((n) => n.id == existing.id);
                  setState(() {});
                  await StorageService.saveNotes(_notes);
                }
              : null,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final filtered = _selectedFolder == 'all'
        ? _notes
        : _notes.where((n) => n.folder == _selectedFolder).toList();

    return CupertinoPageScaffold(
      backgroundColor: const Color(0xFF0C0C0E),
      child: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('SECOND BRAIN', style: TextStyle(color: Color(0xFF71717A), fontSize: 11, fontWeight: FontWeight.w700, letterSpacing: 1.0)),
                          SizedBox(height: 2),
                          Text('Notes', style: TextStyle(color: CupertinoColors.white, fontSize: 26, fontWeight: FontWeight.w700, letterSpacing: -0.5)),
                        ],
                      ),
                      CupertinoButton(
                        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                        color: CupertinoColors.white,
                        borderRadius: BorderRadius.circular(12),
                        onPressed: () => openEditor(),
                        child: const Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(CupertinoIcons.pen, size: 14, color: CupertinoColors.black),
                            SizedBox(width: 4),
                            Text('Write', style: TextStyle(color: CupertinoColors.black, fontSize: 12, fontWeight: FontWeight.w700)),
                          ],
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),

                  // Folder Filter Pills
                  Row(
                    children: ['all', 'journal', 'ideas'].map((f) {
                      final isSel = _selectedFolder == f;
                      return GestureDetector(
                        onTap: () {
                          HapticFeedback.selectionClick();
                          setState(() => _selectedFolder = f);
                        },
                        child: Container(
                          margin: const EdgeInsets.only(right: 8),
                          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                          decoration: BoxDecoration(
                            color: isSel ? CupertinoColors.white : const Color(0xFF131317),
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(color: isSel ? CupertinoColors.white : const Color(0x14FFFFFF)),
                          ),
                          child: Text(
                            f.toUpperCase(),
                            style: TextStyle(
                              color: isSel ? CupertinoColors.black : const Color(0xFF8E8E93),
                              fontSize: 10,
                              fontWeight: FontWeight.w700,
                              letterSpacing: 0.8,
                            ),
                          ),
                        ),
                      );
                    }).toList(),
                  ),
                ],
              ),
            ),

            // Notes Stream
            Expanded(
              child: filtered.isEmpty
                  ? const Center(
                      child: Text('No notes yet. Tap Write to create one.', style: TextStyle(color: Color(0xFF71717A), fontSize: 13)),
                    )
                  : ListView.builder(
                      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 6),
                      itemCount: filtered.length,
                      itemBuilder: (context, index) {
                        final note = filtered[index];
                        return GestureDetector(
                          onTap: () => openEditor(note),
                          child: Container(
                            margin: const EdgeInsets.only(bottom: 10),
                            decoration: BoxDecoration(
                              color: const Color(0xFF131317),
                              borderRadius: BorderRadius.circular(18),
                              border: Border.all(color: const Color(0x14FFFFFF)),
                            ),
                            padding: const EdgeInsets.all(16),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [
                                    Expanded(
                                      child: Text(
                                        note.title.isEmpty ? 'Untitled' : note.title,
                                        style: const TextStyle(color: CupertinoColors.white, fontSize: 15, fontWeight: FontWeight.w700),
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                      ),
                                    ),
                                    Text(
                                      DateFormat('MMM d').format(note.updatedAt),
                                      style: const TextStyle(color: Color(0xFF71717A), fontSize: 11),
                                    ),
                                  ],
                                ),
                                if (note.body.isNotEmpty) ...[
                                  const SizedBox(height: 6),
                                  Text(
                                    note.body,
                                    style: const TextStyle(color: Color(0xFFA1A1AA), fontSize: 13, height: 1.3),
                                    maxLines: 2,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                ],
                              ],
                            ),
                          ),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }
}

class NoteEditorScreen extends StatefulWidget {
  final Note? note;
  final Function(Note) onSave;
  final VoidCallback? onDelete;

  const NoteEditorScreen({super.key, this.note, required this.onSave, this.onDelete});

  @override
  State<NoteEditorScreen> createState() => _NoteEditorScreenState();
}

class _NoteEditorScreenState extends State<NoteEditorScreen> {
  late TextEditingController _titleCtrl;
  late TextEditingController _bodyCtrl;
  String _folder = 'all';

  @override
  void initState() {
    super.initState();
    _titleCtrl = TextEditingController(text: widget.note?.title ?? '');
    _bodyCtrl = TextEditingController(text: widget.note?.body ?? '');
    _folder = widget.note?.folder ?? 'all';
  }

  void _save() {
    final title = _titleCtrl.text.trim();
    final body = _bodyCtrl.text.trim();
    if (title.isEmpty && body.isEmpty) {
      Navigator.of(context).pop();
      return;
    }

    HapticFeedback.lightImpact();
    final note = Note(
      id: widget.note?.id ?? DateTime.now().millisecondsSinceEpoch.toString(),
      title: title.isEmpty ? 'Untitled' : title,
      body: body,
      folder: _folder,
      updatedAt: DateTime.now(),
    );
    widget.onSave(note);
    Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    return CupertinoPageScaffold(
      backgroundColor: const Color(0xFF0C0C0E),
      navigationBar: CupertinoNavigationBar(
        backgroundColor: const Color(0xFF0C0C0E).withOpacity(0.9),
        border: const Border(bottom: BorderSide(color: Color(0x1AFFFFFF))),
        leading: CupertinoButton(
          padding: EdgeInsets.zero,
          onPressed: () => Navigator.of(context).pop(),
          child: const Text('Cancel', style: TextStyle(color: Color(0xFFA1A1AA), fontSize: 14)),
        ),
        trailing: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (widget.onDelete != null)
              CupertinoButton(
                padding: const EdgeInsets.only(right: 8),
                onPressed: () {
                  widget.onDelete?.call();
                  Navigator.of(context).pop();
                },
                child: const Icon(CupertinoIcons.trash, color: Color(0xFFFF453A), size: 18),
              ),
            CupertinoButton(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
              color: CupertinoColors.white,
              borderRadius: BorderRadius.circular(12),
              onPressed: _save,
              child: const Text('Done', style: TextStyle(color: CupertinoColors.black, fontSize: 12, fontWeight: FontWeight.w700)),
            ),
          ],
        ),
      ),
      child: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
          child: Column(
            children: [
              CupertinoTextField(
                controller: _titleCtrl,
                placeholder: 'Title...',
                placeholderStyle: const TextStyle(color: Color(0xFF52525B), fontSize: 20, fontWeight: FontWeight.w700),
                style: const TextStyle(color: CupertinoColors.white, fontSize: 20, fontWeight: FontWeight.w700),
                decoration: const BoxDecoration(),
              ),
              const SizedBox(height: 12),
              Expanded(
                child: CupertinoTextField(
                  controller: _bodyCtrl,
                  placeholder: 'Capture your thoughts, reflections, or ideas...',
                  placeholderStyle: const TextStyle(color: Color(0xFF3F3F46), fontSize: 15),
                  style: const TextStyle(color: Color(0xFFE4E4E7), fontSize: 15, height: 1.4),
                  maxLines: null,
                  expands: true,
                  decoration: const BoxDecoration(),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
