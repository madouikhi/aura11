import 'package:flutter/cupertino.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';
import '../models/note.dart';
import '../services/storage_service.dart';

class NotesView extends StatefulWidget {
  const NotesView({super.key});

  @override
  State<NotesView> createState() => NotesViewState();
}

class NotesViewState extends State<NotesView> {
  List<Note> _notes = [];
  String _currentFolder = 'active'; // 'active', 'archived', 'trash'
  String _searchQuery = '';
  final TextEditingController _searchCtrl = TextEditingController();

  @override
  void initState() {
    super.initState();
    refresh();
  }

  Future<void> refresh() async {
    final list = await StorageService.loadNotes();
    if (mounted) setState(() => _notes = list);
  }

  void openEditor([Note? existing]) {
    HapticFeedback.lightImpact();
    Navigator.of(context).push(
      CupertinoPageRoute(
        fullscreenDialog: true,
        builder: (_) => NoteEditorScreen(
          note: existing,
          onSave: (saved) async {
            if (existing != null) {
              final idx = _notes.indexWhere((n) => n.id == existing.id);
              if (idx != -1) _notes[idx] = saved;
            } else {
              _notes.insert(0, saved);
            }
            setState(() {});
            await StorageService.saveNotes(_notes);
          },
          onArchiveToggle: existing != null
              ? () async {
                  existing.status = existing.status == 'archived' ? 'active' : 'archived';
                  setState(() {});
                  await StorageService.saveNotes(_notes);
                }
              : null,
          onTrashToggle: existing != null
              ? () async {
                  if (existing.status == 'trash') {
                    // Restore to active
                    existing.status = 'active';
                    existing.deletedAt = null;
                  } else {
                    // Move to trash
                    existing.status = 'trash';
                    existing.deletedAt = DateTime.now();
                  }
                  setState(() {});
                  await StorageService.saveNotes(_notes);
                }
              : null,
          onDeletePermanently: existing != null
              ? () async {
                  _notes.removeWhere((n) => n.id == existing.id);
                  setState(() {});
                  await StorageService.saveNotes(_notes);
                }
              : null,
        ),
      ),
    );
  }

  Future<void> _emptyTrashConfirm() async {
    HapticFeedback.heavyImpact();
    showCupertinoDialog(
      context: context,
      builder: (ctx) => CupertinoAlertDialog(
        title: const Text('Empty Trash?'),
        content: const Text('All notes currently in Trash will be permanently deleted.'),
        actions: [
          CupertinoDialogAction(
            isDefaultAction: true,
            child: const Text('Cancel'),
            onPressed: () => Navigator.of(ctx).pop(),
          ),
          CupertinoDialogAction(
            isDestructiveAction: true,
            child: const Text('Empty Trash'),
            onPressed: () async {
              Navigator.of(ctx).pop();
              _notes.removeWhere((n) => n.status == 'trash');
              setState(() {});
              await StorageService.saveNotes(_notes);
            },
          ),
        ],
      ),
    );
  }

  Color _getNoteBgColor(String colorKey) {
    switch (colorKey) {
      case 'amber':
        return const Color(0xFF1E1710);
      case 'emerald':
        return const Color(0xFF0F1A13);
      case 'blue':
        return const Color(0xFF101726);
      case 'purple':
        return const Color(0xFF181124);
      case 'rose':
        return const Color(0xFF221118);
      default:
        return const Color(0xFF131317);
    }
  }

  Color _getNoteBorderColor(String colorKey) {
    switch (colorKey) {
      case 'amber':
        return const Color(0x66FFB340);
      case 'emerald':
        return const Color(0x6634C759);
      case 'blue':
        return const Color(0x66007AFF);
      case 'purple':
        return const Color(0x66AF52DE);
      case 'rose':
        return const Color(0x66FF2D55);
      default:
        return const Color(0x14FFFFFF);
    }
  }

  @override
  Widget build(BuildContext context) {
    // Filter by folder: active | archived | trash
    List<Note> folderNotes = _notes.where((n) {
      if (_currentFolder == 'active') {
        return n.status != 'archived' && n.status != 'trash';
      }
      return n.status == _currentFolder;
    }).toList();

    // Filter by search query
    if (_searchQuery.trim().isNotEmpty) {
      final q = _searchQuery.toLowerCase();
      folderNotes = folderNotes.where((n) {
        return n.title.toLowerCase().contains(q) || n.body.toLowerCase().contains(q);
      }).toList();
    }

    final activeCount = _notes.where((n) => n.status != 'archived' && n.status != 'trash').length;
    final archivedCount = _notes.where((n) => n.status == 'archived').length;
    final trashCount = _notes.where((n) => n.status == 'trash').length;

    return CupertinoPageScaffold(
      backgroundColor: const Color(0xFF0C0C0E),
      child: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Top Title & Write Button
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            _currentFolder == 'active'
                                ? 'REFLECTIONS'
                                : _currentFolder == 'archived'
                                    ? 'ARCHIVED'
                                    : 'TRASH',
                            style: const TextStyle(
                              color: Color(0xFF71717A),
                              fontSize: 11,
                              fontWeight: FontWeight.w700,
                              letterSpacing: 1.0,
                            ),
                          ),
                          const SizedBox(height: 2),
                          Text(
                            _currentFolder == 'active'
                                ? 'Notes'
                                : _currentFolder == 'archived'
                                    ? 'Archive'
                                    : 'Trash',
                            style: const TextStyle(
                              color: CupertinoColors.white,
                              fontSize: 26,
                              fontWeight: FontWeight.w700,
                              letterSpacing: -0.5,
                            ),
                          ),
                        ],
                      ),
                      CupertinoButton(
                        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                        color: CupertinoColors.white,
                        borderRadius: BorderRadius.circular(12),
                        onPressed: () => openEditor(),
                        child: const Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(CupertinoIcons.pen, size: 14, color: CupertinoColors.black),
                            SizedBox(width: 4),
                            Text('Write', style: TextStyle(color: CupertinoColors.black, fontSize: 12, fontWeight: FontWeight.w700)),
                          ],
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),

                  // Folder Switcher: Notes | Archive | Trash (Exact lifelog_preview structure)
                  Container(
                    decoration: BoxDecoration(
                      color: const Color(0xFF131317),
                      borderRadius: BorderRadius.circular(14),
                    ),
                    padding: const EdgeInsets.all(3),
                    child: Row(
                      children: [
                        _buildFolderTab('active', 'Notes', activeCount),
                        _buildFolderTab('archived', 'Archive', archivedCount),
                        _buildFolderTab('trash', 'Trash', trashCount),
                      ],
                    ),
                  ),
                  const SizedBox(height: 10),

                  // Search Bar
                  CupertinoTextField(
                    controller: _searchCtrl,
                    placeholder: 'Search notes...',
                    placeholderStyle: const TextStyle(color: Color(0xFF71717A), fontSize: 12),
                    style: const TextStyle(color: CupertinoColors.white, fontSize: 12),
                    prefix: const Padding(
                      padding: EdgeInsets.only(left: 10),
                      child: Icon(CupertinoIcons.search, size: 14, color: Color(0xFF71717A)),
                    ),
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                    decoration: BoxDecoration(
                      color: const Color(0xFF131317),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: const Color(0x14FFFFFF)),
                    ),
                    onChanged: (val) {
                      setState(() => _searchQuery = val);
                    },
                  ),

                  // 14-Day Trash Notice Banner
                  if (_currentFolder == 'trash') ...[
                    const SizedBox(height: 8),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                      decoration: BoxDecoration(
                        color: const Color(0x1FFF453A),
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(color: const Color(0x33FF453A)),
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          const Row(
                            children: [
                              Icon(CupertinoIcons.info_circle_fill, size: 12, color: Color(0xFFFF453A)),
                              SizedBox(width: 6),
                              Text('Items in Trash auto-delete after 14 days', style: TextStyle(color: Color(0xFFFF6961), fontSize: 10, fontWeight: FontWeight.w500)),
                            ],
                          ),
                          if (trashCount > 0)
                            GestureDetector(
                              onTap: _emptyTrashConfirm,
                              child: const Text('Empty All', style: TextStyle(color: Color(0xFFFF453A), fontSize: 10, fontWeight: FontWeight.w700)),
                            ),
                        ],
                      ),
                    ),
                  ],
                ],
              ),
            ),

            // Notes Stream
            Expanded(
              child: folderNotes.isEmpty
                  ? Center(
                      child: Text(
                        _currentFolder == 'active'
                            ? 'No notes yet. Tap "Write" to begin.'
                            : _currentFolder == 'archived'
                                ? 'No archived notes.'
                                : 'Trash is empty.',
                        style: const TextStyle(color: Color(0xFF71717A), fontSize: 13),
                      ),
                    )
                  : ListView.builder(
                      physics: const BouncingScrollPhysics(),
                      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 4),
                      itemCount: folderNotes.length,
                      itemBuilder: (context, index) {
                        final n = folderNotes[index];
                        final dateStr = DateFormat('MMM d, yyyy').format(n.updatedAt);
                        final cardBg = _getNoteBgColor(n.color);
                        final cardBorder = _getNoteBorderColor(n.color);

                        return GestureDetector(
                          onTap: () => openEditor(n),
                          child: Container(
                            margin: const EdgeInsets.only(bottom: 10),
                            decoration: BoxDecoration(
                              color: cardBg,
                              borderRadius: BorderRadius.circular(16),
                              border: Border.all(color: cardBorder),
                            ),
                            padding: const EdgeInsets.all(14),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [
                                    Expanded(
                                      child: Text(
                                        n.title.isEmpty ? 'Untitled' : n.title,
                                        style: const TextStyle(
                                          color: CupertinoColors.white,
                                          fontSize: 15,
                                          fontWeight: FontWeight.w700,
                                        ),
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                      ),
                                    ),
                                    Text(
                                      dateStr,
                                      style: const TextStyle(color: Color(0xFF71717A), fontSize: 11),
                                    ),
                                  ],
                                ),
                                if (n.body.isNotEmpty) ...[
                                  const SizedBox(height: 6),
                                  Text(
                                    n.body,
                                    style: const TextStyle(
                                      color: Color(0xFFA1A1AA),
                                      fontSize: 12,
                                      height: 1.35,
                                    ),
                                    maxLines: 2,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                ],
                              ],
                            ),
                          ),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildFolderTab(String folderKey, String title, int count) {
    final isSelected = _currentFolder == folderKey;
    return Expanded(
      child: GestureDetector(
        onTap: () {
          HapticFeedback.selectionClick();
          setState(() => _currentFolder = folderKey);
        },
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 7),
          decoration: BoxDecoration(
            color: isSelected ? CupertinoColors.white : CupertinoColors.transparent,
            borderRadius: BorderRadius.circular(11),
          ),
          alignment: Alignment.center,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                title,
                style: TextStyle(
                  color: isSelected ? CupertinoColors.black : const Color(0xFF71717A),
                  fontWeight: FontWeight.w700,
                  fontSize: 12,
                ),
              ),
              const SizedBox(width: 4),
              Text(
                '($count)',
                style: TextStyle(
                  color: isSelected ? CupertinoColors.black : const Color(0xFF52525B),
                  fontSize: 10,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ----------------------------------------------------
// FULL-SCREEN DISTRACTION-FREE APPLE NOTES EDITOR
// WITH ACCENT COLOR PALETTE (AS IN lifelog_preview)
// ----------------------------------------------------
class NoteEditorScreen extends StatefulWidget {
  final Note? note;
  final Function(Note saved) onSave;
  final VoidCallback? onArchiveToggle;
  final VoidCallback? onTrashToggle;
  final VoidCallback? onDeletePermanently;

  const NoteEditorScreen({
    super.key,
    this.note,
    required this.onSave,
    this.onArchiveToggle,
    this.onTrashToggle,
    this.onDeletePermanently,
  });

  @override
  State<NoteEditorScreen> createState() => _NoteEditorScreenState();
}

class _NoteEditorScreenState extends State<NoteEditorScreen> {
  late TextEditingController _titleCtrl;
  late TextEditingController _bodyCtrl;
  String _selectedColor = 'default';
  int _wordCount = 0;

  static const List<Map<String, dynamic>> _colorPalette = [
    {'key': 'default', 'color': Color(0xFF27272A), 'label': 'Slate'},
    {'key': 'amber', 'color': Color(0xFFFFB340), 'label': 'Amber'},
    {'key': 'emerald', 'color': Color(0xFF34C759), 'label': 'Emerald'},
    {'key': 'blue', 'color': Color(0xFF007AFF), 'label': 'Blue'},
    {'key': 'purple', 'color': Color(0xFFAF52DE), 'label': 'Purple'},
    {'key': 'rose', 'color': Color(0xFFFF2D55), 'label': 'Rose'},
  ];

  @override
  void initState() {
    super.initState();
    _titleCtrl = TextEditingController(text: widget.note?.title ?? '');
    _bodyCtrl = TextEditingController(text: widget.note?.body ?? '');
    _selectedColor = widget.note?.color ?? 'default';
    _updateWordCount();
  }

  void _updateWordCount() {
    final text = _bodyCtrl.text.trim();
    setState(() {
      _wordCount = text.isEmpty ? 0 : text.split(RegExp(r'\s+')).length;
    });
  }

  void _save() {
    HapticFeedback.lightImpact();
    var title = _titleCtrl.text.trim();
    final body = _bodyCtrl.text.trim();

    // Apple Notes Auto-Title if empty
    if (title.isEmpty && body.isNotEmpty) {
      final firstLine = body.split('\n')[0].trim();
      title = firstLine.length > 35 ? '${firstLine.substring(0, 35)}...' : firstLine;
    }

    if (title.isEmpty && body.isEmpty) {
      Navigator.of(context).pop();
      return;
    }

    final savedNote = Note(
      id: widget.note?.id ?? DateTime.now().millisecondsSinceEpoch.toString(),
      title: title.isEmpty ? 'Untitled' : title,
      body: body,
      status: widget.note?.status ?? 'active',
      color: _selectedColor,
      updatedAt: DateTime.now(),
      deletedAt: widget.note?.deletedAt,
    );

    widget.onSave(savedNote);
    Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    final dateStr = DateFormat('EEEE, MMM d').format(DateTime.now());

    return CupertinoPageScaffold(
      backgroundColor: const Color(0xFF0C0C0E),
      navigationBar: CupertinoNavigationBar(
        backgroundColor: const Color(0xFF0C0C0E).withOpacity(0.9),
        border: const Border(bottom: BorderSide(color: Color(0x1AFFFFFF))),
        leading: CupertinoButton(
          padding: EdgeInsets.zero,
          onPressed: _save,
          child: const Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(CupertinoIcons.chevron_left, size: 18, color: CupertinoColors.white),
              SizedBox(width: 4),
              Text('Notes', style: TextStyle(color: CupertinoColors.white, fontSize: 14)),
            ],
          ),
        ),
        middle: Text(
          dateStr,
          style: const TextStyle(color: Color(0xFF71717A), fontSize: 11, fontWeight: FontWeight.w600),
        ),
        trailing: CupertinoButton(
          padding: EdgeInsets.zero,
          onPressed: _save,
          child: const Text('Done', style: TextStyle(color: CupertinoColors.white, fontSize: 14, fontWeight: FontWeight.w700)),
        ),
      ),
      child: SafeArea(
        child: Column(
          children: [
            // ACCENT COLOR PICKER PALETTE
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
              decoration: const BoxDecoration(
                border: Border(bottom: BorderSide(color: Color(0x14FFFFFF), width: 0.5)),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text(
                    'ACCENT',
                    style: TextStyle(color: Color(0xFF71717A), fontSize: 10, fontWeight: FontWeight.w700, letterSpacing: 1.0),
                  ),
                  Row(
                    children: _colorPalette.map((item) {
                      final key = item['key'] as String;
                      final col = item['color'] as Color;
                      final isSelected = _selectedColor == key;
                      return GestureDetector(
                        onTap: () {
                          HapticFeedback.selectionClick();
                          setState(() => _selectedColor = key);
                        },
                        child: Container(
                          margin: const EdgeInsets.symmetric(horizontal: 4),
                          width: 22,
                          height: 22,
                          decoration: BoxDecoration(
                            color: col.withOpacity(0.3),
                            shape: BoxShape.circle,
                            border: Border.all(
                              color: isSelected ? CupertinoColors.white : col.withOpacity(0.6),
                              width: isSelected ? 2 : 1,
                            ),
                          ),
                          child: isSelected
                              ? const Icon(CupertinoIcons.checkmark, size: 11, color: CupertinoColors.white)
                              : null,
                        ),
                      );
                    }).toList(),
                  ),
                ],
              ),
            ),

            // Writing Area
            Expanded(
              child: ListView(
                physics: const BouncingScrollPhysics(),
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
                children: [
                  CupertinoTextField(
                    controller: _titleCtrl,
                    placeholder: 'Title',
                    placeholderStyle: const TextStyle(color: Color(0xFF3F3F46), fontSize: 20, fontWeight: FontWeight.w700),
                    style: const TextStyle(color: CupertinoColors.white, fontSize: 20, fontWeight: FontWeight.w700),
                    decoration: null,
                    padding: EdgeInsets.zero,
                  ),
                  const SizedBox(height: 12),
                  CupertinoTextField(
                    controller: _bodyCtrl,
                    placeholder: 'Start typing your thoughts, ideas, or reflections...',
                    placeholderStyle: const TextStyle(color: Color(0xFF3F3F46), fontSize: 14, height: 1.5),
                    style: const TextStyle(color: Color(0xFFE4E4E7), fontSize: 14, height: 1.5),
                    maxLines: null,
                    decoration: null,
                    padding: EdgeInsets.zero,
                    onChanged: (_) => _updateWordCount(),
                  ),
                ],
              ),
            ),

            // Bottom Utility Bar
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
              decoration: const BoxDecoration(
                border: Border(top: BorderSide(color: Color(0x14FFFFFF), width: 0.5)),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    '$_wordCount ${_wordCount == 1 ? "word" : "words"}',
                    style: const TextStyle(color: Color(0xFF71717A), fontSize: 11),
                  ),
                  Row(
                    children: [
                      // Archive Action
                      if (widget.onArchiveToggle != null) ...[
                        CupertinoButton(
                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                          onPressed: () {
                            HapticFeedback.mediumImpact();
                            widget.onArchiveToggle!();
                            Navigator.of(context).pop();
                          },
                          child: Icon(
                            widget.note?.status == 'archived' ? CupertinoIcons.archivebox_fill : CupertinoIcons.archivebox,
                            size: 18,
                            color: const Color(0xFF8E8E93),
                          ),
                        ),
                      ],
                      // Trash / Delete Action
                      if (widget.onTrashToggle != null) ...[
                        CupertinoButton(
                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                          onPressed: () {
                            HapticFeedback.mediumImpact();
                            widget.onTrashToggle!();
                            Navigator.of(context).pop();
                          },
                          child: Icon(
                            widget.note?.status == 'trash' ? CupertinoIcons.arrow_uturn_left : CupertinoIcons.trash,
                            size: 18,
                            color: widget.note?.status == 'trash' ? const Color(0xFF34C759) : const Color(0xFFFF453A),
                          ),
                        ),
                      ],
                      if (widget.note?.status == 'trash' && widget.onDeletePermanently != null) ...[
                        CupertinoButton(
                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                          onPressed: () {
                            HapticFeedback.heavyImpact();
                            widget.onDeletePermanently!();
                            Navigator.of(context).pop();
                          },
                          child: const Icon(CupertinoIcons.xmark_circle_fill, size: 18, color: Color(0xFFFF453A)),
                        ),
                      ],
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
