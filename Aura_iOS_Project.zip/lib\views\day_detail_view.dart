import 'package:flutter/cupertino.dart';
import '../models/day_archive.dart';

class DayDetailView extends StatelessWidget {
  final DayArchive archive;

  const DayDetailView({super.key, required this.archive});

  @override
  Widget build(BuildContext context) {
    return CupertinoPageScaffold(
      backgroundColor: const Color(0xFF0C0C0E),
      navigationBar: CupertinoNavigationBar(
        backgroundColor: const Color(0xFF0C0C0E).withOpacity(0.9),
        border: const Border(bottom: BorderSide(color: Color(0x1AFFFFFF))),
        leading: CupertinoButton(
          padding: EdgeInsets.zero,
          onPressed: () => Navigator.of(context).pop(),
          child: const Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(CupertinoIcons.chevron_left, size: 18, color: CupertinoColors.white),
              SizedBox(width: 4),
              Text('History', style: TextStyle(color: CupertinoColors.white, fontSize: 14)),
            ],
          ),
        ),
        middle: const Text(
          'DAY ARCHIVE',
          style: TextStyle(
            color: Color(0xFF8E8E93),
            fontSize: 11,
            letterSpacing: 1.2,
            fontWeight: FontWeight.w600,
          ),
        ),
      ),
      child: SafeArea(
        child: ListView(
          physics: const BouncingScrollPhysics(),
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
          children: [
            // Header
            Text(
              archive.date,
              style: const TextStyle(
                color: CupertinoColors.white,
                fontSize: 26,
                fontWeight: FontWeight.w700,
                letterSpacing: -0.5,
              ),
            ),
            const SizedBox(height: 4),
            Row(
              children: [
                const Icon(CupertinoIcons.globe, size: 13, color: Color(0xFF34C759)),
                const SizedBox(width: 5),
                Text(
                  archive.location,
                  style: const TextStyle(color: Color(0xFF8E8E93), fontSize: 13),
                ),
              ],
            ),
            const SizedBox(height: 20),

            // Sleep Card
            Container(
              decoration: BoxDecoration(
                color: const Color(0xFF131317),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: const Color(0x14FFFFFF)),
              ),
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Row(
                        children: [
                          Icon(CupertinoIcons.moon_fill, size: 16, color: Color(0xFF5E5CE6)),
                          SizedBox(width: 8),
                          Text('SLEEP', style: TextStyle(color: Color(0xFF8E8E93), fontSize: 11, fontWeight: FontWeight.w700, letterSpacing: 1.0)),
                        ],
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                        decoration: BoxDecoration(
                          color: const Color(0x1FFFFFFF),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Text(archive.sleepHours, style: const TextStyle(color: CupertinoColors.white, fontSize: 12, fontWeight: FontWeight.w600)),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      Expanded(
                        child: Container(
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            color: const Color(0xFF1A1A20),
                            borderRadius: BorderRadius.circular(14),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text('Bedtime', style: TextStyle(color: Color(0xFF71717A), fontSize: 11)),
                              const SizedBox(height: 2),
                              Text(archive.bedtime, style: const TextStyle(color: CupertinoColors.white, fontSize: 15, fontWeight: FontWeight.w700)),
                            ],
                          ),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Container(
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            color: const Color(0xFF1A1A20),
                            borderRadius: BorderRadius.circular(14),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text('Wake Up', style: TextStyle(color: Color(0xFF71717A), fontSize: 11)),
                              const SizedBox(height: 2),
                              Text(archive.waketime, style: const TextStyle(color: CupertinoColors.white, fontSize: 15, fontWeight: FontWeight.w700)),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 18),

            // Daily Prayers Section
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text('DAILY PRAYERS', style: TextStyle(color: Color(0xFF71717A), fontSize: 11, fontWeight: FontWeight.w700, letterSpacing: 1.0)),
                Text('${archive.prayersDone}/5 Completed', style: const TextStyle(color: Color(0xFF5E5CE6), fontSize: 12, fontWeight: FontWeight.w600)),
              ],
            ),
            const SizedBox(height: 8),
            Container(
              decoration: BoxDecoration(
                color: const Color(0xFF131317),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: const Color(0x14FFFFFF)),
              ),
              padding: const EdgeInsets.all(12),
              child: Row(
                children: ['Fajr', 'Dhuhr', 'Asr', 'Maghrib', 'Isha'].map((pName) {
                  final bool isDone = archive.prayers[pName] ?? false;
                  return Expanded(
                    child: Container(
                      margin: const EdgeInsets.symmetric(horizontal: 2.5),
                      padding: const EdgeInsets.symmetric(vertical: 8),
                      decoration: BoxDecoration(
                        color: isDone ? const Color(0x1F34C759) : const Color(0xFF1A1A20),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(
                          color: isDone ? const Color(0x8034C759) : const Color(0x14FFFFFF),
                        ),
                      ),
                      alignment: Alignment.center,
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(
                            isDone ? CupertinoIcons.checkmark_alt : CupertinoIcons.circle,
                            size: 13,
                            color: isDone ? const Color(0xFF34C759) : const Color(0xFF52525B),
                          ),
                          const SizedBox(height: 3),
                          Text(
                            pName,
                            style: TextStyle(
                              color: isDone ? CupertinoColors.white : const Color(0xFF8E8E93),
                              fontSize: 10,
                              fontWeight: isDone ? FontWeight.w700 : FontWeight.w500,
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                }).toList(),
              ),
            ),
            const SizedBox(height: 20),

            // Tasks Section
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text('COMPLETED TASKS', style: TextStyle(color: Color(0xFF71717A), fontSize: 11, fontWeight: FontWeight.w700, letterSpacing: 1.0)),
                Text('${archive.tasksDone}/${archive.tasksTotal} Done', style: const TextStyle(color: Color(0xFF34C759), fontSize: 12, fontWeight: FontWeight.w600)),
              ],
            ),
            const SizedBox(height: 8),
            Container(
              decoration: BoxDecoration(
                color: const Color(0xFF131317),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: const Color(0x14FFFFFF)),
              ),
              padding: const EdgeInsets.all(14),
              child: archive.tasks.isEmpty
                  ? const Text('No tasks recorded for this day.', style: TextStyle(color: Color(0xFF71717A), fontSize: 13, fontStyle: FontStyle.italic))
                  : Column(
                      children: archive.tasks.map((t) {
                        return Padding(
                          padding: const EdgeInsets.symmetric(vertical: 6),
                          child: Row(
                            children: [
                              Icon(
                                t.completed ? CupertinoIcons.checkmark_circle_fill : CupertinoIcons.circle,
                                size: 18,
                                color: t.completed ? const Color(0xFF34C759) : const Color(0xFF71717A),
                              ),
                              const SizedBox(width: 10),
                              Expanded(
                                child: Text(
                                  t.text,
                                  style: TextStyle(
                                    color: t.completed ? const Color(0xFF71717A) : CupertinoColors.white,
                                    fontSize: 14,
                                    decoration: t.completed ? TextDecoration.lineThrough : null,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        );
                      }).toList(),
                    ),
            ),
            const SizedBox(height: 20),

            // Notes Section
            if (archive.notes.isNotEmpty) ...[
              const Text('DAY NOTES', style: TextStyle(color: Color(0xFF71717A), fontSize: 11, fontWeight: FontWeight.w700, letterSpacing: 1.0)),
              const SizedBox(height: 8),
              ...archive.notes.map((n) {
                return Container(
                  margin: const EdgeInsets.only(bottom: 8),
                  decoration: BoxDecoration(
                    color: const Color(0xFF131317),
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: const Color(0x14FFFFFF)),
                  ),
                  padding: const EdgeInsets.all(14),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(n.title, style: const TextStyle(color: CupertinoColors.white, fontSize: 14, fontWeight: FontWeight.w700)),
                      if (n.preview.isNotEmpty) ...[
                        const SizedBox(height: 4),
                        Text(n.preview, style: const TextStyle(color: Color(0xFFA1A1AA), fontSize: 12, height: 1.35)),
                      ],
                    ],
                  ),
                );
              }),
            ],
            const SizedBox(height: 30),
          ],
        ),
      ),
    );
  }
}
