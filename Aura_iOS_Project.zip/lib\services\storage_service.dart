import 'dart:convert';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/task.dart';
import '../models/note.dart';
import '../models/day_archive.dart';
import 'location_service.dart';

class StorageService {
  static const String _keyTasks = 'aura_flutter_tasks';
  static const String _keyNotes = 'aura_flutter_notes';
  static const String _keyHistory = 'aura_flutter_history';
  static const String _keyLastDate = 'aura_last_active_date';
  static const String _keySleep = 'aura_sleep_times';

  static Future<List<Task>> loadTasks() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_keyTasks);
    if (raw == null || raw.isEmpty) return [];
    try {
      final list = jsonDecode(raw) as List<dynamic>;
      return list.map((e) => Task.fromJson(e as Map<String, dynamic>)).toList();
    } catch (_) {
      return [];
    }
  }

  static Future<void> saveTasks(List<Task> tasks) async {
    final prefs = await SharedPreferences.getInstance();
    final raw = jsonEncode(tasks.map((e) => e.toJson()).toList());
    await prefs.setString(_keyTasks, raw);
  }

  static Future<List<Note>> loadNotes() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_keyNotes);
    if (raw == null || raw.isEmpty) return [];
    try {
      final list = jsonDecode(raw) as List<dynamic>;
      return list.map((e) => Note.fromJson(e as Map<String, dynamic>)).toList();
    } catch (_) {
      return [];
    }
  }

  static Future<void> saveNotes(List<Note> notes) async {
    final prefs = await SharedPreferences.getInstance();
    final raw = jsonEncode(notes.map((e) => e.toJson()).toList());
    await prefs.setString(_keyNotes, raw);
  }

  static Future<List<DayArchive>> loadHistory() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_keyHistory);
    if (raw == null || raw.isEmpty) {
      // Default sample archives for immediate discovery
      final samples = [
        DayArchive(
          id: 'demo_1',
          date: 'Sep 26, 2026',
          location: 'Karamursel, Türkiye',
          sleepHours: '7.5 hrs',
          bedtime: '23:30',
          waketime: '07:00',
          tasksDone: 3,
          tasksTotal: 4,
          tasks: [
            ArchivedTask(text: 'Morning workout & stretch', completed: true),
            ArchivedTask(text: 'Aura architecture review', completed: true),
            ArchivedTask(text: 'Deep work focus block (2h)', completed: true),
            ArchivedTask(text: 'Evening walk & winddown', completed: false),
          ],
          notes: [
            ArchivedNote(title: 'Minimalist Workflow', preview: 'Focus on 4 core priorities daily without clutter.'),
          ],
        ),
        DayArchive(
          id: 'demo_2',
          date: 'Sep 25, 2026',
          location: 'Karamursel, Türkiye',
          sleepHours: '8.0 hrs',
          bedtime: '23:00',
          waketime: '07:00',
          tasksDone: 4,
          tasksTotal: 4,
          tasks: [
            ArchivedTask(text: 'Setup Supabase cloud sync', completed: true),
            ArchivedTask(text: 'Refine dark mode palette', completed: true),
            ArchivedTask(text: 'Verify audio notifications', completed: true),
            ArchivedTask(text: 'Prepare iOS build bundle', completed: true),
          ],
          notes: [],
        ),
      ];
      await saveHistory(samples);
      return samples;
    }
    try {
      final list = jsonDecode(raw) as List<dynamic>;
      return list.map((e) => DayArchive.fromJson(e as Map<String, dynamic>)).toList();
    } catch (_) {
      return [];
    }
  }

  static Future<void> saveHistory(List<DayArchive> history) async {
    final prefs = await SharedPreferences.getInstance();
    final raw = jsonEncode(history.map((e) => e.toJson()).toList());
    await prefs.setString(_keyHistory, raw);
  }

  static Future<Map<String, String>> loadSleepTimes() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_keySleep);
    if (raw == null) return {'start': '23:30', 'end': '07:00'};
    try {
      final map = jsonDecode(raw) as Map<String, dynamic>;
      return {
        'start': map['start'] ?? '23:30',
        'end': map['end'] ?? '07:00',
      };
    } catch (_) {
      return {'start': '23:30', 'end': '07:00'};
    }
  }

  static Future<void> saveSleepTimes(String start, String end) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_keySleep, jsonEncode({'start': start, 'end': end}));
  }

  // Automated Day Rollover Engine
  static Future<void> checkAndPerformMidnightRollover() async {
    final loc = await LocationService.getLocation();
    await checkDayRollover(loc);
  }

  static Future<void> checkDayRollover(String currentLocation) async {
    final prefs = await SharedPreferences.getInstance();
    final todayStr = DateFormat('MMM d, yyyy').format(DateTime.now());
    final lastActive = prefs.getString(_keyLastDate);

    if (lastActive == null) {
      await prefs.setString(_keyLastDate, todayStr);
      return;
    }

    if (lastActive != todayStr) {
      // Day has changed!
      final tasks = await loadTasks();
      final notes = await loadNotes();
      final history = await loadHistory();
      final sleepTimes = await loadSleepTimes();

      final todayTasks = tasks.where((t) => t.bucket == 'today').toList();
      final doneCount = todayTasks.where((t) => t.isCompleted).length;

      // Filter notes updated on yesterday's date
      final yesterdayNotes = notes.where((n) {
        return DateFormat('MMM d, yyyy').format(n.updatedAt) == lastActive;
      }).map((n) => ArchivedNote(title: n.title, preview: n.body)).toList();

      // Create DayArchive
      final archive = DayArchive(
        id: 'archive_${DateTime.now().millisecondsSinceEpoch}',
        date: lastActive,
        location: currentLocation,
        sleepHours: '7.5 hrs',
        bedtime: sleepTimes['start'] ?? '23:30',
        waketime: sleepTimes['end'] ?? '07:00',
        tasksDone: doneCount,
        tasksTotal: todayTasks.length,
        tasks: todayTasks.map((t) => ArchivedTask(text: t.title, completed: t.isCompleted)).toList(),
        notes: yesterdayNotes,
      );

      history.insert(0, archive);
      await saveHistory(history);

      // Unfinished tasks are given rolledOver: true and placed below today's tasks
      final unfinishedYesterday = todayTasks.where((t) => !t.isCompleted).map((t) {
        t.rolledOver = true;
        return t;
      }).toList();

      final laterTasks = tasks.where((t) => t.bucket != 'today').toList();
      final updatedTasks = [...unfinishedYesterday, ...laterTasks];
      await saveTasks(updatedTasks);

      await prefs.setString(_keyLastDate, todayStr);
    }
  }
}
