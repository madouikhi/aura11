import 'dart:convert';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/task.dart';
import '../models/note.dart';
import '../models/day_archive.dart';
import 'location_service.dart';

class StorageService {
  static const String _keyTasks = 'aura_flutter_tasks';
  static const String _keyNotes = 'aura_flutter_notes';
  static const String _keyHistory = 'aura_flutter_history';
  static const String _keyLastDate = 'aura_last_active_date';
  static const String _keySleep = 'aura_sleep_times';
  static const String _keyBedAlarm = 'aura_bed_alarm_enabled';
  static const String _keyWakeAlarm = 'aura_wake_alarm_enabled';

  // --- TASKS ---
  static Future<List<Task>> loadTasks() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_keyTasks);
    if (raw == null || raw.isEmpty) return [];
    try {
      final list = jsonDecode(raw) as List<dynamic>;
      return list.map((e) => Task.fromJson(e as Map<String, dynamic>)).toList();
    } catch (_) {
      return [];
    }
  }

  static Future<void> saveTasks(List<Task> tasks) async {
    final prefs = await SharedPreferences.getInstance();
    final raw = jsonEncode(tasks.map((e) => e.toJson()).toList());
    await prefs.setString(_keyTasks, raw);
  }

  // --- NOTES (WITH 14-DAY AUTO PURGE FOR TRASH) ---
  static Future<List<Note>> loadNotes() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_keyNotes);
    if (raw == null || raw.isEmpty) return [];
    try {
      final list = (jsonDecode(raw) as List<dynamic>)
          .map((e) => Note.fromJson(e as Map<String, dynamic>))
          .toList();

      // 14-Day Auto Purge for Trash
      final now = DateTime.now();
      final beforeCount = list.length;
      final activeAndValid = list.where((n) {
        if (n.status == 'trash' && n.deletedAt != null) {
          final diffDays = now.difference(n.deletedAt!).inDays;
          return diffDays < 14; // Keep only if less than 14 days old
        }
        return true;
      }).toList();

      if (activeAndValid.length != beforeCount) {
        await saveNotes(activeAndValid);
      }

      return activeAndValid;
    } catch (_) {
      return [];
    }
  }

  static Future<void> saveNotes(List<Note> notes) async {
    final prefs = await SharedPreferences.getInstance();
    final raw = jsonEncode(notes.map((e) => e.toJson()).toList());
    await prefs.setString(_keyNotes, raw);
  }

  // --- HISTORY ---
  static Future<List<DayArchive>> loadHistory() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_keyHistory);
    if (raw == null || raw.isEmpty) {
      final samples = [
        DayArchive(
          id: 'demo_1',
          date: 'Sep 26, 2026',
          location: 'Türkiye',
          sleepHours: '7.5 hrs',
          bedtime: '23:30',
          waketime: '07:00',
          tasksDone: 3,
          tasksTotal: 4,
          tasks: [
            ArchivedTask(text: 'Morning workout & stretch', completed: true),
            ArchivedTask(text: 'Aura architecture review', completed: true),
            ArchivedTask(text: 'Deep work focus block (2h)', completed: true),
            ArchivedTask(text: 'Evening walk & winddown', completed: false),
          ],
          notes: [
            ArchivedNote(title: 'Minimalist Workflow', preview: 'Focus on 4 core priorities daily without clutter.'),
          ],
        ),
      ];
      await saveHistory(samples);
      return samples;
    }
    try {
      final list = jsonDecode(raw) as List<dynamic>;
      return list.map((e) => DayArchive.fromJson(e as Map<String, dynamic>)).toList();
    } catch (_) {
      return [];
    }
  }

  static Future<void> saveHistory(List<DayArchive> history) async {
    final prefs = await SharedPreferences.getInstance();
    final raw = jsonEncode(history.map((e) => e.toJson()).toList());
    await prefs.setString(_keyHistory, raw);
  }

  // --- SLEEP & SEPARATE BED/WAKE ALARMS ---
  static Future<Map<String, String>> loadSleepTimes() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_keySleep);
    if (raw == null) return {'start': '23:30', 'end': '07:00'};
    try {
      final map = jsonDecode(raw) as Map<String, dynamic>;
      return {
        'start': map['start'] ?? '23:30',
        'end': map['end'] ?? '07:00',
      };
    } catch (_) {
      return {'start': '23:30', 'end': '07:00'};
    }
  }

  static Future<void> saveSleepTimes(String start, String end) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_keySleep, jsonEncode({'start': start, 'end': end}));
  }

  static Future<bool> loadBedAlarmEnabled() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getBool(_keyBedAlarm) ?? true;
  }

  static Future<void> saveBedAlarmEnabled(bool enabled) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_keyBedAlarm, enabled);
  }

  static Future<bool> loadWakeAlarmEnabled() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getBool(_keyWakeAlarm) ?? true;
  }

  static Future<void> saveWakeAlarmEnabled(bool enabled) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_keyWakeAlarm, enabled);
  }

  // --- FIVE DAILY PRAYERS (FIXED, SEPARATE FROM TASKS) ---
  static const List<String> prayerNames = [
    'Fajr',
    'Dhuhr',
    'Asr',
    'Maghrib',
    'Isha'
  ];

  static String _prayerKeyForDate(DateTime dt) {
    return 'aura_prayers_${DateFormat('yyyy-MM-dd').format(dt)}';
  }

  static Future<Map<String, bool>> loadTodayPrayers() async {
    final prefs = await SharedPreferences.getInstance();
    final key = _prayerKeyForDate(DateTime.now());
    final raw = prefs.getString(key);
    final Map<String, bool> result = {
      for (final p in prayerNames) p: false,
    };
    if (raw != null && raw.isNotEmpty) {
      try {
        final decoded = jsonDecode(raw) as Map<String, dynamic>;
        for (final p in prayerNames) {
          if (decoded.containsKey(p)) {
            result[p] = decoded[p] == true;
          }
        }
      } catch (_) {}
    }
    return result;
  }

  static Future<void> saveTodayPrayers(Map<String, bool> prayers) async {
    final prefs = await SharedPreferences.getInstance();
    final key = _prayerKeyForDate(DateTime.now());
    await prefs.setString(key, jsonEncode(prayers));
  }

  static Future<void> togglePrayer(String prayerName) async {
    final current = await loadTodayPrayers();
    current[prayerName] = !(current[prayerName] ?? false);
    await saveTodayPrayers(current);
  }

  // --- LOCAL DATA EXPORT & IMPORT (ZERO CLOUD DEPENDENCY) ---
  static Future<String> exportAllDataJson() async {
    final tasks = await loadTasks();
    final notes = await loadNotes();
    final history = await loadHistory();
    final sleep = await loadSleepTimes();
    final bedAlarm = await loadBedAlarmEnabled();
    final wakeAlarm = await loadWakeAlarmEnabled();
    final prayers = await loadTodayPrayers();

    final data = {
      'app': 'Aura',
      'version': '2.1.0',
      'exported_at': DateTime.now().toIso8601String(),
      'tasks': tasks.map((t) => t.toJson()).toList(),
      'notes': notes.map((n) => n.toJson()).toList(),
      'history': history.map((h) => h.toJson()).toList(),
      'sleep': sleep,
      'bed_alarm_enabled': bedAlarm,
      'wake_alarm_enabled': wakeAlarm,
      'prayers': prayers,
    };

    return const JsonEncoder.withIndent('  ').convert(data);
  }

  static Future<bool> importAllDataFromJson(String jsonString) async {
    try {
      final decoded = jsonDecode(jsonString.trim()) as Map<String, dynamic>;
      
      if (decoded['tasks'] != null) {
        final list = (decoded['tasks'] as List<dynamic>)
            .map((e) => Task.fromJson(Map<String, dynamic>.from(e as Map)))
            .toList();
        await saveTasks(list);
      }

      if (decoded['notes'] != null) {
        final list = (decoded['notes'] as List<dynamic>)
            .map((e) => Note.fromJson(Map<String, dynamic>.from(e as Map)))
            .toList();
        await saveNotes(list);
      }

      if (decoded['history'] != null) {
        final list = (decoded['history'] as List<dynamic>)
            .map((e) => DayArchive.fromJson(Map<String, dynamic>.from(e as Map)))
            .toList();
        await saveHistory(list);
      }

      if (decoded['sleep'] != null) {
        final smap = Map<String, dynamic>.from(decoded['sleep'] as Map);
        await saveSleepTimes(
          smap['start']?.toString() ?? '23:30',
          smap['end']?.toString() ?? '07:00',
        );
      }

      if (decoded['bed_alarm_enabled'] != null) {
        await saveBedAlarmEnabled(decoded['bed_alarm_enabled'] == true);
      }
      if (decoded['wake_alarm_enabled'] != null) {
        await saveWakeAlarmEnabled(decoded['wake_alarm_enabled'] == true);
      }

      if (decoded['prayers'] != null) {
        final pmap = Map<String, dynamic>.from(decoded['prayers'] as Map);
        final Map<String, bool> prayers = {};
        for (final p in prayerNames) {
          prayers[p] = pmap[p] == true;
        }
        await saveTodayPrayers(prayers);
      }

      return true;
    } catch (_) {
      return false;
    }
  }

  // --- FACTORY RESET (WIPE EVERYTHING & START FRESH) ---
  static Future<void> resetAllData() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();
  }

  // --- AUTOMATED DAY ROLLOVER ENGINE ---
  static Future<void> checkAndPerformMidnightRollover() async {
    final country = await LocationService.getLocation();
    await checkDayRollover(country);
  }

  static Future<void> checkDayRollover(String currentLocation) async {
    final prefs = await SharedPreferences.getInstance();
    final todayStr = DateFormat('MMM d, yyyy').format(DateTime.now());
    final lastActive = prefs.getString(_keyLastDate);

    if (lastActive == null) {
      await prefs.setString(_keyLastDate, todayStr);
      return;
    }

    if (lastActive != todayStr) {
      final tasks = await loadTasks();
      final notes = await loadNotes();
      final history = await loadHistory();
      final sleepTimes = await loadSleepTimes();
      final yesterdayPrayers = await loadTodayPrayers();
      final prayersDone = yesterdayPrayers.values.where((v) => v).length;

      final todayTasks = tasks.where((t) => t.bucket == 'today').toList();
      final doneCount = todayTasks.where((t) => t.isCompleted).length;

      final yesterdayNotes = notes.where((n) {
        return n.status != 'trash' && DateFormat('MMM d, yyyy').format(n.updatedAt) == lastActive;
      }).map((n) => ArchivedNote(title: n.title, preview: n.body)).toList();

      final archive = DayArchive(
        id: 'archive_${DateTime.now().millisecondsSinceEpoch}',
        date: lastActive,
        location: currentLocation,
        sleepHours: '7.5 hrs',
        bedtime: sleepTimes['start'] ?? '23:30',
        waketime: sleepTimes['end'] ?? '07:00',
        tasksDone: doneCount,
        tasksTotal: todayTasks.length,
        tasks: todayTasks.map((t) => ArchivedTask(text: t.title, completed: t.isCompleted)).toList(),
        notes: yesterdayNotes,
        prayersDone: prayersDone,
        prayersTotal: 5,
        prayers: yesterdayPrayers,
      );

      history.insert(0, archive);
      await saveHistory(history);

      final unfinishedYesterday = todayTasks.where((t) => !t.isCompleted).map((t) {
        t.rolledOver = true;
        return t;
      }).toList();

      final laterTasks = tasks.where((t) => t.bucket != 'today').toList();
      final updatedTasks = [...unfinishedYesterday, ...laterTasks];
      await saveTasks(updatedTasks);

      await prefs.setString(_keyLastDate, todayStr);
    }
  }
}
