import 'package:flutter/cupertino.dart';
import 'package:flutter/services.dart';
import '../models/task.dart';
import '../services/storage_service.dart';

class TasksView extends StatefulWidget {
  const TasksView({super.key});

  @override
  State<TasksView> createState() => TasksViewState();
}

class TasksViewState extends State<TasksView> {
  List<Task> _tasks = [];
  String _activeBucket = 'today';
  final TextEditingController _textCtrl = TextEditingController();

  @override
  void initState() {
    super.initState();
    refresh();
  }

  Future<void> refresh() async {
    final list = await StorageService.loadTasks();
    if (mounted) setState(() => _tasks = list);
  }

  Future<void> _addTask() async {
    final text = _textCtrl.text.trim();
    if (text.isEmpty) return;

    final todayTasks = _tasks.where((t) => t.bucket == 'today').toList();
    if (_activeBucket == 'today' && todayTasks.length >= 4) {
      // 4 max reached
      HapticFeedback.heavyImpact();
      return;
    }

    HapticFeedback.mediumImpact();
    final newTask = Task(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      title: text,
      bucket: _activeBucket,
    );

    setState(() {
      _tasks.insert(0, newTask);
      _textCtrl.clear();
    });

    await StorageService.saveTasks(_tasks);
  }

  Future<void> _toggleTask(Task task) async {
    HapticFeedback.lightImpact();
    setState(() {
      task.isCompleted = !task.isCompleted;
    });
    await StorageService.saveTasks(_tasks);
  }

  Future<void> _deleteTask(String id) async {
    HapticFeedback.mediumImpact();
    setState(() {
      _tasks.removeWhere((t) => t.id == id);
    });
    await StorageService.saveTasks(_tasks);
  }

  Future<void> _rescheduleTask(Task task, String newBucket) async {
    HapticFeedback.lightImpact();
    if (newBucket == 'today') {
      final todayCount = _tasks.where((t) => t.bucket == 'today').length;
      if (todayCount >= 4) {
        HapticFeedback.heavyImpact();
        return;
      }
    }
    setState(() {
      task.bucket = newBucket;
    });
    await StorageService.saveTasks(_tasks);
  }

  @override
  Widget build(BuildContext context) {
    // Separate today tasks
    final rawToday = _tasks.where((t) => t.bucket == 'today').toList();
    // Sort: Fresh tasks at the top, Yesterday's rolledOver tasks placed below them!
    rawToday.sort((a, b) {
      if (a.rolledOver == b.rolledOver) return 0;
      return a.rolledOver ? 1 : -1;
    });

    final laterTasks = _tasks.where((t) => t.bucket == 'later').toList();
    final displayedTasks = _activeBucket == 'today' ? rawToday : laterTasks;
    final isTodayFull = rawToday.length >= 4;

    return CupertinoPageScaffold(
      backgroundColor: const Color(0xFF0C0C0E),
      child: SafeArea(
        child: Column(
          children: [
            // Top Section
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'DAILY PRIORITIES',
                    style: TextStyle(
                      color: Color(0xFF71717A),
                      fontSize: 11,
                      fontWeight: FontWeight.w700,
                      letterSpacing: 1.0,
                    ),
                  ),
                  const SizedBox(height: 2),
                  const Text(
                    'Focus List',
                    style: TextStyle(
                      color: CupertinoColors.white,
                      fontSize: 26,
                      fontWeight: FontWeight.w700,
                      letterSpacing: -0.5,
                    ),
                  ),
                  const SizedBox(height: 14),

                  // Bucket Switcher (Today vs Later)
                  Container(
                    decoration: BoxDecoration(
                      color: const Color(0xFF131317),
                      borderRadius: BorderRadius.circular(14),
                    ),
                    padding: const EdgeInsets.all(3),
                    child: Row(
                      children: [
                        Expanded(
                          child: GestureDetector(
                            onTap: () {
                              HapticFeedback.selectionClick();
                              setState(() => _activeBucket = 'today');
                            },
                            child: Container(
                              padding: const EdgeInsets.symmetric(vertical: 8),
                              decoration: BoxDecoration(
                                color: _activeBucket == 'today' ? CupertinoColors.white : CupertinoColors.transparent,
                                borderRadius: BorderRadius.circular(11),
                              ),
                              alignment: Alignment.center,
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Text(
                                    'Today',
                                    style: TextStyle(
                                      color: _activeBucket == 'today' ? CupertinoColors.black : const Color(0xFF71717A),
                                      fontWeight: FontWeight.w700,
                                      fontSize: 12,
                                    ),
                                  ),
                                  const SizedBox(width: 4),
                                  Text(
                                    '(${rawToday.length}/4)',
                                    style: TextStyle(
                                      color: _activeBucket == 'today' ? CupertinoColors.black : const Color(0xFF52525B),
                                      fontSize: 11,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                        Expanded(
                          child: GestureDetector(
                            onTap: () {
                              HapticFeedback.selectionClick();
                              setState(() => _activeBucket = 'later');
                            },
                            child: Container(
                              padding: const EdgeInsets.symmetric(vertical: 8),
                              decoration: BoxDecoration(
                                color: _activeBucket == 'later' ? CupertinoColors.white : CupertinoColors.transparent,
                                borderRadius: BorderRadius.circular(11),
                              ),
                              alignment: Alignment.center,
                              child: Text(
                                'Later (${laterTasks.length})',
                                style: TextStyle(
                                  color: _activeBucket == 'later' ? CupertinoColors.black : const Color(0xFF71717A),
                                  fontWeight: FontWeight.w700,
                                  fontSize: 12,
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 12),

                  // Input Field
                  if (_activeBucket == 'today' && isTodayFull)
                    Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: const Color(0x1FFF9F0A),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: const Color(0x33FF9F0A)),
                      ),
                      child: const Row(
                        children: [
                          Icon(CupertinoIcons.info_circle_fill, size: 14, color: Color(0xFFFF9F0A)),
                          SizedBox(width: 8),
                          Text('Today is full (4 max limit). Focus on these.', style: TextStyle(color: Color(0xFFFF9F0A), fontSize: 11, fontWeight: FontWeight.w600)),
                        ],
                      ),
                    )
                  else
                    Row(
                      children: [
                        Expanded(
                          child: CupertinoTextField(
                            controller: _textCtrl,
                            placeholder: _activeBucket == 'today' ? "New priority..." : "Add to queue...",
                            placeholderStyle: const TextStyle(color: Color(0xFF52525B), fontSize: 13),
                            style: const TextStyle(color: CupertinoColors.white, fontSize: 13),
                            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                            decoration: BoxDecoration(
                              color: const Color(0xFF131317),
                              borderRadius: BorderRadius.circular(12),
                              border: Border.all(color: const Color(0x14FFFFFF)),
                            ),
                            onSubmitted: (_) => _addTask(),
                          ),
                        ),
                        const SizedBox(width: 8),
                        CupertinoButton(
                          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                          color: CupertinoColors.white,
                          borderRadius: BorderRadius.circular(12),
                          onPressed: _addTask,
                          child: const Icon(CupertinoIcons.plus, size: 16, color: CupertinoColors.black),
                        ),
                      ],
                    ),
                ],
              ),
            ),

            // Tasks List
            Expanded(
              child: displayedTasks.isEmpty
                  ? Center(
                      child: Text(
                        _activeBucket == 'today' ? 'Your Today focus is clear.' : 'No tasks in the queue.',
                        style: const TextStyle(color: Color(0xFF71717A), fontSize: 13),
                      ),
                    )
                  : ListView.builder(
                      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 6),
                      itemCount: displayedTasks.length,
                      itemBuilder: (context, index) {
                        final task = displayedTasks[index];
                        return Dismissible(
                          key: Key(task.id),
                          direction: DismissDirection.endToStart,
                          background: Container(
                            alignment: Alignment.centerRight,
                            padding: const EdgeInsets.only(right: 20),
                            decoration: BoxDecoration(
                              color: const Color(0x40FF453A),
                              borderRadius: BorderRadius.circular(16),
                            ),
                            child: const Icon(CupertinoIcons.trash, color: Color(0xFFFF453A), size: 18),
                          ),
                          onDismissed: (_) => _deleteTask(task.id),
                          child: Container(
                            margin: const EdgeInsets.only(bottom: 8),
                            decoration: BoxDecoration(
                              color: const Color(0xFF131317),
                              borderRadius: BorderRadius.circular(16),
                              border: Border.all(color: const Color(0x14FFFFFF)),
                            ),
                            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 13),
                            child: Row(
                              children: [
                                GestureDetector(
                                  onTap: () => _toggleTask(task),
                                  child: Icon(
                                    task.isCompleted ? CupertinoIcons.check_mark_circled_solid : CupertinoIcons.circle,
                                    size: 19,
                                    color: task.isCompleted ? const Color(0xFF34C759) : const Color(0xFF71717A),
                                  ),
                                ),
                                const SizedBox(width: 12),
                                Expanded(
                                  child: Text(
                                    task.title,
                                    style: TextStyle(
                                      color: task.isCompleted ? const Color(0xFF71717A) : CupertinoColors.white,
                                      fontSize: 14,
                                      fontWeight: FontWeight.w500,
                                      decoration: task.isCompleted ? TextDecoration.lineThrough : null,
                                    ),
                                  ),
                                ),
                                if (task.rolledOver) ...[
                                  Container(
                                    padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                                    decoration: BoxDecoration(
                                      color: const Color(0x26FF9F0A),
                                      borderRadius: BorderRadius.circular(6),
                                      border: Border.all(color: const Color(0x40FF9F0A)),
                                    ),
                                    child: const Text('Yesterday', style: TextStyle(color: Color(0xFFFF9F0A), fontSize: 9, fontWeight: FontWeight.w700)),
                                  ),
                                  const SizedBox(width: 6),
                                ],
                                CupertinoButton(
                                  padding: EdgeInsets.zero,
                                  onPressed: () {
                                    final nextBucket = task.bucket == 'today' ? 'later' : 'today';
                                    _rescheduleTask(task, nextBucket);
                                  },
                                  child: Icon(
                                    task.bucket == 'today' ? CupertinoIcons.arrow_right_circle : CupertinoIcons.arrow_left_circle,
                                    size: 18,
                                    color: const Color(0xFF71717A),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }
}
