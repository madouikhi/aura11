import 'package:audioplayers/audioplayers.dart';

class AudioService {
  static final AudioPlayer _player = AudioPlayer();
  static bool _isRinging = false;

  static bool get isRinging => _isRinging;

  static Future<void> playWakeAlarmLoop() async {
    try {
      await _player.stop();
      _isRinging = true;
      await _player.setReleaseMode(ReleaseMode.loop);
      await _player.play(AssetSource('audio/wake.mp3'));
    } catch (_) {
      _isRinging = false;
    }
  }

  static Future<void> playSleepAlarmLoop() async {
    try {
      await _player.stop();
      _isRinging = true;
      await _player.setReleaseMode(ReleaseMode.loop);
      await _player.play(AssetSource('audio/sleep.mp3'));
    } catch (_) {
      _isRinging = false;
    }
  }

  static Future<void> stop() async {
    try {
      await _player.setReleaseMode(ReleaseMode.release);
      await _player.stop();
      _isRinging = false;
    } catch (_) {
      _isRinging = false;
    }
  }
}
