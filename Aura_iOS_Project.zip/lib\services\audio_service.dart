import 'package:audioplayers/audioplayers.dart';

class AudioService {
  static final AudioPlayer _player = AudioPlayer();
  static bool _isPlaying = false;

  static bool get isPlaying => _isPlaying;

  static Future<void> playWake() async {
    try {
      await _player.stop();
      _isPlaying = true;
      _player.onPlayerComplete.listen((_) => _isPlaying = false);
      await _player.play(AssetSource('audio/wake.mp3'));
    } catch (_) {
      _isPlaying = false;
    }
  }

  static Future<void> playSleep() async {
    try {
      await _player.stop();
      _isPlaying = true;
      _player.onPlayerComplete.listen((_) => _isPlaying = false);
      await _player.play(AssetSource('audio/sleep.mp3'));
    } catch (_) {
      _isPlaying = false;
    }
  }

  static Future<void> stop() async {
    try {
      await _player.stop();
      _isPlaying = false;
    } catch (_) {}
  }
}
