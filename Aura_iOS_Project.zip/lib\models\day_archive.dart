class ArchivedTask {
  final String text;
  final bool completed;

  ArchivedTask({required this.text, required this.completed});

  Map<String, dynamic> toJson() => {'text': text, 'completed': completed};
  factory ArchivedTask.fromJson(Map<String, dynamic> json) =>
      ArchivedTask(text: json['text'] ?? '', completed: json['completed'] ?? false);
}

class ArchivedNote {
  final String title;
  final String preview;

  ArchivedNote({required this.title, required this.preview});

  Map<String, dynamic> toJson() => {'title': title, 'preview': preview};
  factory ArchivedNote.fromJson(Map<String, dynamic> json) =>
      ArchivedNote(title: json['title'] ?? '', preview: json['preview'] ?? '');
}

class DayArchive {
  final String id;
  final String date;
  final String location;
  final String sleepHours;
  final String bedtime;
  final String waketime;
  final int tasksDone;
  final int tasksTotal;
  final List<ArchivedTask> tasks;
  final List<ArchivedNote> notes;

  DayArchive({
    required this.id,
    required this.date,
    required this.location,
    required this.sleepHours,
    required this.bedtime,
    required this.waketime,
    required this.tasksDone,
    required this.tasksTotal,
    required this.tasks,
    required this.notes,
  });

  Map<String, dynamic> toJson() => {
    'id': id,
    'date': date,
    'location': location,
    'sleepHours': sleepHours,
    'bedtime': bedtime,
    'waketime': waketime,
    'tasksDone': tasksDone,
    'tasksTotal': tasksTotal,
    'tasks': tasks.map((t) => t.toJson()).toList(),
    'notes': notes.map((n) => n.toJson()).toList(),
  };

  factory DayArchive.fromJson(Map<String, dynamic> json) => DayArchive(
    id: json['id'] ?? '',
    date: json['date'] ?? '',
    location: json['location'] ?? 'Local Region',
    sleepHours: json['sleepHours'] ?? '7.5 hrs',
    bedtime: json['bedtime'] ?? '23:30',
    waketime: json['waketime'] ?? '07:00',
    tasksDone: json['tasksDone'] ?? 0,
    tasksTotal: json['tasksTotal'] ?? 4,
    tasks: (json['tasks'] as List<dynamic>? ?? [])
        .map((t) => ArchivedTask.fromJson(t))
        .toList(),
    notes: (json['notes'] as List<dynamic>? ?? [])
        .map((n) => ArchivedNote.fromJson(n))
        .toList(),
  );
}
