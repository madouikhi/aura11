import 'package:flutter/cupertino.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';
import '../services/audio_service.dart';

class AlarmRingingView extends StatefulWidget {
  final bool isWake;

  const AlarmRingingView({super.key, required this.isWake});

  @override
  State<AlarmRingingView> createState() => _AlarmRingingViewState();
}

class _AlarmRingingViewState extends State<AlarmRingingView> with SingleTickerProviderStateMixin {
  late AnimationController _pulseCtrl;

  @override
  void initState() {
    super.initState();
    _pulseCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1000),
    )..repeat(reverse: true);

    // Play looping alarm sound
    if (widget.isWake) {
      AudioService.playWakeAlarmLoop();
    } else {
      AudioService.playSleepAlarmLoop();
    }
  }

  @override
  void dispose() {
    _pulseCtrl.dispose();
    AudioService.stop();
    super.dispose();
  }

  void _dismissAlarm() {
    HapticFeedback.heavyImpact();
    AudioService.stop();
    Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    final now = DateTime.now();
    final timeStr = DateFormat('HH:mm').format(now);
    final dateStr = DateFormat('EEEE, MMM d').format(now);

    // PopScope with canPop: false ensures back gesture CANNOT dismiss alarm!
    return PopScope(
      canPop: false,
      child: CupertinoPageScaffold(
        backgroundColor: const Color(0xFF070709),
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 24),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                // Top Indicator
                Column(
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                      decoration: BoxDecoration(
                        color: widget.isWake ? const Color(0x33FFB340) : const Color(0x335E5CE6),
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(
                          color: widget.isWake ? const Color(0x80FFB340) : const Color(0x805E5CE6),
                        ),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(
                            widget.isWake ? CupertinoIcons.sun_max_fill : CupertinoIcons.moon_fill,
                            size: 16,
                            color: widget.isWake ? const Color(0xFFFFB340) : const Color(0xFF5E5CE6),
                          ),
                          const SizedBox(width: 8),
                          Text(
                            widget.isWake ? 'WAKE UP ALARM' : 'BEDTIME ALARM',
                            style: TextStyle(
                              color: widget.isWake ? const Color(0xFFFFB340) : const Color(0xFF5E5CE6),
                              fontSize: 12,
                              fontWeight: FontWeight.w800,
                              letterSpacing: 1.2,
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 10),
                    Text(
                      dateStr,
                      style: const TextStyle(color: Color(0xFF8E8E93), fontSize: 14, fontWeight: FontWeight.w500),
                    ),
                  ],
                ),

                // Center Pulsing Time
                AnimatedBuilder(
                  animation: _pulseCtrl,
                  builder: (context, child) {
                    final scale = 1.0 + (_pulseCtrl.value * 0.05);
                    return Transform.scale(
                      scale: scale,
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text(
                            timeStr,
                            style: const TextStyle(
                              color: CupertinoColors.white,
                              fontSize: 72,
                              fontWeight: FontWeight.w800,
                              letterSpacing: -2.0,
                            ),
                          ),
                          const SizedBox(height: 10),
                          Text(
                            widget.isWake
                                ? 'Good morning. Start your focus.'
                                : 'Time to wind down and rest.',
                            style: const TextStyle(
                              color: Color(0xFFA1A1AA),
                              fontSize: 15,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ],
                      ),
                    );
                  },
                ),

                // Bottom: Exclusive ONLY Dismiss Button
                Column(
                  children: [
                    const Text(
                      'Press button below to stop alarm',
                      style: TextStyle(color: Color(0xFF71717A), fontSize: 12, fontWeight: FontWeight.w500),
                    ),
                    const SizedBox(height: 16),
                    SizedBox(
                      width: double.infinity,
                      height: 58,
                      child: CupertinoButton(
                        color: CupertinoColors.white,
                        borderRadius: BorderRadius.circular(20),
                        onPressed: _dismissAlarm,
                        child: const Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(CupertinoIcons.bell_slash_fill, size: 20, color: CupertinoColors.black),
                            SizedBox(width: 10),
                            Text(
                              'STOP ALARM',
                              style: TextStyle(
                                color: CupertinoColors.black,
                                fontSize: 16,
                                fontWeight: FontWeight.w800,
                                letterSpacing: 0.5,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
