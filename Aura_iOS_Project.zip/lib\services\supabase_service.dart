import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class SupabaseService {
  static const String _defaultUrl = 'https://ehboncsmawfhhrwggrha.supabase.co';
  static const String _defaultKey = 'sb_publishable_e4oA2Ae6d9rnnVh5w80AtA_bOIbktEv';

  static Future<String> getUrl() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('aura_supabase_url') ?? _defaultUrl;
  }

  static Future<String> getKey() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('aura_supabase_key') ?? _defaultKey;
  }

  static Future<void> saveCredentials(String url, String key) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('aura_supabase_url', url.trim());
    await prefs.setString('aura_supabase_key', key.trim());
  }

  static Future<bool> pushBackup(Map<String, dynamic> payload) async {
    try {
      final url = (await getUrl()).replaceAll(RegExp(r'/+$'), '');
      final key = await getKey();

      final body = jsonEncode({
        'id': 'aura_user_backup',
        'data': payload,
        'updated_at': DateTime.now().toIso8601String(),
      });

      final res = await http.post(
        Uri.parse('$url/rest/v1/aura_sync?on_conflict=id'),
        headers: {
          'apikey': key,
          'Authorization': 'Bearer $key',
          'Content-Type': 'application/json',
          'Prefer': 'resolution=merge-duplicates',
        },
        body: body,
      ).timeout(const Duration(seconds: 8));

      return res.statusCode == 200 || res.statusCode == 201;
    } catch (_) {
      return false;
    }
  }

  static Future<Map<String, dynamic>?> pullBackup() async {
    try {
      final url = (await getUrl()).replaceAll(RegExp(r'/+$'), '');
      final key = await getKey();

      final res = await http.get(
        Uri.parse('$url/rest/v1/aura_sync?id=eq.aura_user_backup&select=data'),
        headers: {
          'apikey': key,
          'Authorization': 'Bearer $key',
          'Accept': 'application/json',
        },
      ).timeout(const Duration(seconds: 8));

      if (res.statusCode == 200) {
        final list = jsonDecode(res.body) as List<dynamic>;
        if (list.isNotEmpty && list[0]['data'] != null) {
          return list[0]['data'] as Map<String, dynamic>;
        }
      }
      return null;
    } catch (_) {
      return null;
    }
  }
}
