import 'dart:async';
import 'package:flutter/cupertino.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';
import 'services/storage_service.dart';
import 'services/location_service.dart';
import 'state/app_state.dart';
import 'views/today_view.dart';
import 'views/tasks_view.dart';
import 'views/notes_view.dart';
import 'views/history_view.dart';
import 'views/settings_view.dart';
import 'views/alarm_ringing_view.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Lock to portrait mode for consistent iOS presentation
  await SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
  ]);

  // Set pure black navigation & status bar
  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      statusBarColor: CupertinoColors.transparent,
      statusBarBrightness: Brightness.dark,
      statusBarIconBrightness: Brightness.light,
    ),
  );

  // Check midnight rollover automatically on launch
  await StorageService.checkAndPerformMidnightRollover();

  // Initialize unified central app state
  await appState.init();

  runApp(const AuraApp());
}

class AuraApp extends StatelessWidget {
  const AuraApp({super.key});

  @override
  Widget build(BuildContext context) {
    return const CupertinoApp(
      title: 'Aura',
      debugShowCheckedModeBanner: false,
      theme: CupertinoThemeData(
        brightness: Brightness.dark,
        primaryColor: CupertinoColors.white,
        scaffoldBackgroundColor: Color(0xFF0C0C0E),
        barBackgroundColor: Color(0xCC0C0C0E),
        textTheme: CupertinoTextThemeData(
          primaryColor: CupertinoColors.white,
          textStyle: TextStyle(
            color: CupertinoColors.white,
            fontSize: 14,
            letterSpacing: -0.2,
          ),
        ),
      ),
      home: AuraMainScaffold(),
    );
  }
}

class AuraMainScaffold extends StatefulWidget {
  const AuraMainScaffold({super.key});

  @override
  State<AuraMainScaffold> createState() => _AuraMainScaffoldState();
}

class _AuraMainScaffoldState extends State<AuraMainScaffold> {
  final CupertinoTabController _tabController = CupertinoTabController();
  Offset? _swipeStart;
  bool _validSwipeStart = false;
  Timer? _alarmTimer;
  String _lastTriggeredMin = '';

  @override
  void initState() {
    super.initState();
    _startAlarmCheck();
  }

  @override
  void dispose() {
    _alarmTimer?.cancel();
    super.dispose();
  }

  void _startAlarmCheck() {
    _alarmTimer = Timer.periodic(const Duration(seconds: 15), (_) async {
      final now = DateTime.now();
      final currentMin = DateFormat('HH:mm').format(now);
      if (currentMin == _lastTriggeredMin) return;

      if (appState.wakeAlarmEnabled && currentMin == appState.waketime) {
        _lastTriggeredMin = currentMin;
        _triggerAlarm(true);
      } else if (appState.bedAlarmEnabled && currentMin == appState.bedtime) {
        _lastTriggeredMin = currentMin;
        _triggerAlarm(false);
      }
    });
  }

  void _triggerAlarm(bool isWake) {
    HapticFeedback.heavyImpact();
    Navigator.of(context).push(
      CupertinoPageRoute(
        fullscreenDialog: true,
        builder: (_) => AlarmRingingView(isWake: isWake),
      ),
    );
  }

  void _onPointerDown(PointerDownEvent event) {
    final size = MediaQuery.of(context).size;
    final x = event.position.dx;
    final y = event.position.dy;

    // Strict Rule: Swipe must start in the bottom 30% height and right 50% width
    if (y >= size.height * 0.70 && x >= size.width * 0.50) {
      _swipeStart = event.position;
      _validSwipeStart = true;
    } else {
      _validSwipeStart = false;
      _swipeStart = null;
    }
  }

  void _onPointerMove(PointerMoveEvent event) {
    if (!_validSwipeStart || _swipeStart == null) return;
    final dx = event.position.dx - _swipeStart!.dx;
    final dy = (event.position.dy - _swipeStart!.dy).abs();

    // Swipe from right to left: horizontal displacement <= -50px, minimal vertical wander
    if (dx <= -50 && dy < 75) {
      _validSwipeStart = false;
      _swipeStart = null;
      _openSettings();
    }
  }

  void _onPointerUp(PointerUpEvent event) {
    _validSwipeStart = false;
    _swipeStart = null;
  }

  void _onPointerCancel(PointerCancelEvent event) {
    _validSwipeStart = false;
    _swipeStart = null;
  }

  void _openSettings() {
    HapticFeedback.mediumImpact();
    Navigator.of(context).push(
      CupertinoPageRoute(
        fullscreenDialog: true,
        builder: (ctx) => SettingsView(
          onClose: () => Navigator.of(ctx).pop(),
        ),
      ),
    );
  }

  void _openNoteEditorFromToday() {
    HapticFeedback.lightImpact();
    Navigator.of(context).push(
      CupertinoPageRoute(
        fullscreenDialog: true,
        builder: (_) => NoteEditorScreen(
          onSave: (saved) {
            appState.saveNote(saved);
          },
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Listener(
      behavior: HitTestBehavior.translucent,
      onPointerDown: _onPointerDown,
      onPointerMove: _onPointerMove,
      onPointerUp: _onPointerUp,
      onPointerCancel: _onPointerCancel,
      child: CupertinoTabScaffold(
        controller: _tabController,
        tabBar: CupertinoTabBar(
          backgroundColor: const Color(0xE60C0C0E),
          activeColor: CupertinoColors.white,
          inactiveColor: const Color(0xFF636366),
          border: const Border(
            top: BorderSide(color: Color(0x1AFFFFFF), width: 0.5),
          ),
          iconSize: 22,
          items: const [
            BottomNavigationBarItem(
              icon: Icon(CupertinoIcons.sun_max),
              activeIcon: Icon(CupertinoIcons.sun_max_fill),
              label: 'Today',
            ),
            BottomNavigationBarItem(
              icon: Icon(CupertinoIcons.checkmark_circle),
              activeIcon: Icon(CupertinoIcons.checkmark_circle_fill),
              label: 'Tasks',
            ),
            BottomNavigationBarItem(
              icon: Icon(CupertinoIcons.square_pencil),
              activeIcon: Icon(CupertinoIcons.square_pencil_fill),
              label: 'Notes',
            ),
            BottomNavigationBarItem(
              icon: Icon(CupertinoIcons.clock),
              activeIcon: Icon(CupertinoIcons.clock_fill),
              label: 'History',
            ),
          ],
        ),
        tabBuilder: (context, index) {
          switch (index) {
            case 0:
              return CupertinoTabView(
                builder: (_) => TodayView(
                  onOpenNoteEditor: _openNoteEditorFromToday,
                ),
              );
            case 1:
              return CupertinoTabView(
                builder: (_) => const TasksView(),
              );
            case 2:
              return CupertinoTabView(
                builder: (_) => const NotesView(),
              );
            case 3:
              return CupertinoTabView(
                builder: (_) => const HistoryView(),
              );
            default:
              return CupertinoTabView(
                builder: (_) => TodayView(
                  onOpenNoteEditor: _openNoteEditorFromToday,
                ),
              );
          }
        },
      ),
    );
  }
}
